<?php
    session_start();
    session_regenerate_id(true);

    require_once('../common/common.php');

    login_check();

    $select_year = $_SESSION["select_year"];
    $select_month = $_SESSION["select_month"];
    $select_day = $_SESSION["select_day"];
    $select_time = $_SESSION["select_time"];
    $select_seat = $_SESSION["select_seat"];
    $user_name = $_SESSION['user_name'];

    // $select_year = '2023';
    // $select_month = '06';
    // $select_day = '20';
    // $select_time = '08:30';
    // $select_seat = '1';
    // $user_name = $_SESSION['user_name'];

    try
    {
        $now_date = "{$select_year}-{$select_month}-{$select_day}";
        $n_datetime = new DateTime($now_date);

        $nf_datetime = $n_datetime -> format("Y-m-d");
        if($now_date === $nf_datetime){
            $dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
            $user = 'root';
            $password = '';
            $dbh = new PDO($dsn, $user, $password);
            $dbh -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $sql = 'SELECT user_id FROM user_info WHERE user_name=?';
            $stmt = $dbh -> prepare($sql);
            $data[] = $user_name;
            $stmt -> execute($data);

            $rec = $stmt -> fetch(PDO::FETCH_ASSOC);
            $user_id = $rec['user_id'];

            $sql = 'SELECT res_id FROM reserve WHERE user_id=? AND res_date=? AND res_time=?';
            $stmt = $dbh -> prepare($sql);
            $data = array();
            $data[] = $user_id;
            $data[] = $now_date;
            $data[] = $select_time;
            $stmt -> execute($data);

            $rec = $stmt -> fetchAll(PDO::FETCH_ASSOC);
            $c_rec = count($rec);

            $sql = 'SELECT can_id FROM cancel WHERE user_id=? AND can_date=? AND can_time=?';
            $stmt2 = $dbh -> prepare($sql);
            $data = array();
            $data[] = $user_id;
            $data[] = $now_date;
            $data[] = $select_time;
            $stmt2 -> execute($data);

            $rec2 = $stmt2 -> fetchAll(PDO::FETCH_ASSOC);
            $c_rec2 = count($rec2);
        
            if(count($rec) <= 0){
                // $no_res_seat=
                // "{$select_year}年{$select_month}月{$select_day}日　{$select_time}　発の予約はありません".
                // '<br><br><button type="button" onclick="history.back()">戻る</button>';
                // exit();
                if(count($rec2) <= 0){
                    $no_res_seat=
                    "{$select_year}年{$select_month}月{$select_day}日　{$select_time}　発の予約はありません".
                    '<br><br><button type="button" onclick="history.back()">戻る</button>';
                    // exit();
                }
            }

            $dbh = null;
        }else{
            $non_day=
            "{$select_year}年{$select_month}月に{$select_day}日はありません。".
            '<br><br><button type="button" onclick="history.back()">戻る</button>';
            // exit();
        }
    }
    catch(Exception $e)
    {
        print 'ただいまご迷惑をお掛けしております。';
        print $e;
        exit();
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>キャンセル確認画面</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
    	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .form {
                width: auto;
                background: #fdfdfd;
                opacity: 0.95;
                padding-left: 30px;
                padding-right: 30px;            
                padding-top: 20px;
                padding-bottom: 20px;
                border-radius: 20px;
                box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
                text-align: center;
            }
            label {
                color:black;
            }
            table {
              color: black;
            }
            table td, table th {
                color: black;
            }
            h1{
                text-align: center;
            }
            .links{
                text-align: right;
            }
            h3{
            color:black;
            }
            h2{
                color:black;
            }

            /* body {
                margin-left: 400px;
                margin-right: 400px;
                padding: 50px;
            }

            .link {
                text-align: right;
            } */
        </style>
    </head>
    <body class="all">
    <header>  
        <p>キャンセル確認画面</p> 
    </header>
		<br><br>
        <div class="form-container">
			<div class="form">
				<label>
    <?php
        if (isset($no_res_seat) && $no_res_seat !== '') {
            echo $no_res_seat;
            exit();
        }
        if (isset($non_day) && $non_day !== '') {
            echo $non_day;
            exit();
        }
    ?>


        <h3>以下の内容でキャンセルを実行します。<br>
            よろしいですか？</h3>
        <h2>
        <?php print $select_year ?>年
        <?php print $select_month ?>月
        <?php print $select_day ?>日
        <?php print $select_time ?> 発
        <br>
        <?php print '座席番号:  '.$select_seat ?>
        </h2>
        <br>
        <button onclick="location.href='res_status.php'">戻る</button>
        <button onclick="location.href='can_done.php'">ＯＫ</button>
                </label>
            </div>
		</div>
    </body>
</html>