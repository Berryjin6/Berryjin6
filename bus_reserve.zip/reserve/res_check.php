<?php
    session_start();
    session_regenerate_id(true);

    require_once('../common/common.php'); 
    login_check();


    // 変数代入
    $select_year = $_SESSION['select_year'];
    $select_month = $_SESSION['select_month'];
    $select_day = $_SESSION['select_day'];
    $select_time = $_SESSION['select_time'];
    $select_seat = $_SESSION['select_seat'];
    $user_name = $_SESSION['user_name'];
        
    try{
        $now_date = "{$select_year}-{$select_month}-{$select_day}";

        $now_d = new DateTime();
        $now_d -> modify('+1day');
        $nowf_d = $now_d -> format("Y-m-d");

        $n_datetime = new DateTime($now_date);
        $nf_datetime = $n_datetime -> format("Y-m-d");

        if($select_seat == ''){
            $res_non_select_seat=
            '<div class="center">'.
            '座席が選択されていません。<br />'.
            '<br /><br />'.
            '<button>'.
            '<a href="res_status.php">座席状況に戻る</a>'.
            '</button>'.
            '</div>';
        }

        if($nowf_d > $nf_datetime){
            $res_cannot=
            '<div class="center">'.
            '予約は翌日以降しかできません。<br />'.
            '<br /><br />'.
            '<button>'.
            '<a href="res_status.php">座席状況に戻る</a>'.
            '</button>'.
            '</div>';
        };

        //bus DB接続
        $dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
        $user = 'root';
        $password = '';
        $dbh = new PDO($dsn,$user,$password);
        $dbh -> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

        //ログイン中のuser_nameで、user_idを取得
        $sql = 'SELECT user_id FROM user_info WHERE user_name=?';
        $stmt = $dbh->prepare($sql);
        $data[] = $user_name;
        $stmt -> execute($data);

        //user_infoテーブルからレコードを取り出し、変数$user_idを代入
        $rec = $stmt -> fetch(PDO::FETCH_ASSOC);
        $user_id = $rec['user_id'];
        // var_dump($rec);//test

        $sql = 'SELECT res_id FROM reserve WHERE res_seat=? AND res_date=? AND res_time=? ';
        $stmt = $dbh->prepare($sql);
        $data = array();
        $data[] = $select_seat;
        $data[] = $now_date;
        $data[] = $select_time;
        $stmt -> execute($data);

        $rec = $stmt -> fetch(PDO::FETCH_ASSOC);

        // var_dump($rec);//test

        if(isset($rec['res_id'])){
            $res_already=
            '<div class="center">'.
            'すでに予約が入っています。<br />'.
            '<br /><br />'.
            '<button>'.
            '<a href="res_status.php">座席状況に戻る</a>'.
            '</button>'.
            '</div>';
        }

        $sql = 'SELECT res_id FROM reserve WHERE user_id=? AND res_date=?';
        $stmt = $dbh->prepare($sql);
        $data = array();
        $data[] = $user_id;
        $data[] = $now_date;
        $stmt -> execute($data);

        $rec2 = $stmt -> fetch(PDO::FETCH_ASSOC);

        if(isset($rec2['res_id'])){
            $res_day_already=
            '<div class="center">'.
            '同じ日に予約が入っています。<br />'.
            '<br /><br />'.
            '<button>'.
            '<a href="res_status.php">座席状況に戻る</a>'.
            '</button>'.
            '<div class="center">';
        }


        $dbh = null;   
    }
    catch(Exception $e)
    {
        print'ただいま障害により大変ご迷惑をお掛けしております。';
        exit();
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>座席予約完了画面</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .form {
                width: auto;
                background: #fdfdfd;
                opacity: 0.95;
                padding-left: 30px;
                padding-right: 30px;
                padding-top: 30px;
                padding-bottom: 30px;
                border-radius: 20px;
                box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
            }
            /* a {
                color:black;
            } */
            button{
                color:white;
                text-align:center;
            }
            .white{
                color:white;
            }
            .center{
                text-align:center;
                color:black;
            }
            h3{
                color:black;
            }
            h2{
                color:black;
            }
        </style>
    </head>
    <body class="all">
        <header>  
            <!--  <i class="fa fa-bus" style="font-size:80px;color:rgb(6, 5, 18)"></i>    -->
            <p>予約確認画面</p> 
        </header>
		<br><br>
        <div class="form-container">
			<div class="form">
				<label>
<?php
    if (isset($res_non_select_seat) && $res_non_select_seat !== '') {
        echo $res_non_select_seat;
        exit();
    }
    if (isset($res_cannot) && $res_cannot !== '') {
        echo $res_cannot;
        exit();
    }
    if (isset($res_already) && $res_already !== '') {
    echo $res_already;
    exit();
    }

    if (isset($res_day_already) && $res_day_already !== '') {
        echo $res_day_already;
        exit();
    }

?>
        <div class="center">
        <br />
        <h3>以下の内容で予約します。よろしいですか？</h3>
        <br />
        <h2>
        <?php print $select_year ?>年
        <?php print $select_month ?>月
        <?php print $select_day ?>日
        <?php print substr($select_time, 0, 5) ?> 発
        <br /><br />
        座席番号：<?php print $select_seat ?>
        </h2>
        <br /><br />
        <button onclick="location.href='res_status.php'">戻る</button>　　
        <button onclick="location.href='res_done.php'">ＯＫ</button> 
        </div>

        <!--teat-->
        <!-- <form method="post" action="res_done.php">
             <input type="hidden" name="user_name" value="">
            <input type="hidden" name="select_year" value="">
            <input type="hidden" name="select_month" value=">
            <input type="hidden" name="select_day" value="<">
            <input type="hidden" name="select_time" value="">
            <input type="hidden" name="select_seat" value=""> -->
            <!-- <input type="submit" value="送信">            
        </form> --> 
                </label>
            </div>
		</div>
    </body>
</html>