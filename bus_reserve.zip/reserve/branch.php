<?php
    session_start();
    session_regenerate_id(true);
    
    $action = $_POST['select_action'];
    $year = $_POST['select_year'];
    $month = $_POST['select_month'];
    $day = $_POST['select_day'];
    $time = $_POST['select_time'];
    $seat = $_POST['select_seat'];

    $_SESSION['select_year'] = $year;
    $_SESSION['select_month'] = $month;
    $_SESSION['select_day'] = $day;
    $_SESSION['select_time'] = $time;
    $_SESSION['select_seat'] = $seat;

    switch($action){
        case 0:
            header('Location:res_check.php');
            exit();
            break;

        case 1:
            header('Location:can_check.php');
            exit();
            break;
    
        case 2:
            header('Location:can_res_check.php');
            exit();
            break;
    }

    // if($action == 2){

    //     header('Location:can_res_check.php');
    //     exit();
    // }

    // if($action == 1){

    //     header('Location:can_check.php');
    //     exit();
    // }
?>