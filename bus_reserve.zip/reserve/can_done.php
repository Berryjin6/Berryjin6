<?php
    session_start();
    session_regenerate_id(true);

    require_once('../common/common.php');

    login_check();

    $select_year = $_SESSION["select_year"];
    $select_month = $_SESSION["select_month"];
    $select_day = $_SESSION["select_day"];
    $select_time = $_SESSION["select_time"];
    if(isset($_SESSION["select_seat"])){
        $select_seat = $_SESSION["select_seat"];
    }
    $user_name = $_SESSION['user_name'];
    $user_id = $_SESSION['user_id'];

    // $select_year = '2023';
    // $select_month = '01';
    // $select_day = '20';
    // $select_time = '08:00';
    // $select_seat = '1';
    // $user_name = 'aho';
    // $res_id = '1';

    // print '<div class="link">';
    // if(isset($admin_name)==true){
    //     print '管理者：'.$admin_name;
    //     print '　　';
    //     print '<a href="../admin_top.php" id="admin">管理者ページ</a>';
    //     print '<br />';
    // }else{
    //     print '<br />';
    //     print $user_name.'さんログイン中';
    // }
    // print '　　';
    // print '<a href="../logout.php" id="logout">ログアウト</a>';
    // print '</div>';

    try
        {
        $now_date = "{$select_year}-{$select_month}-{$select_day}";

        $dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
        $user = 'root';
        $password = '';
        $dbh = new PDO($dsn, $user, $password);
        $dbh -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $sql = 'SELECT user_id FROM user_info WHERE user_name=?';
        $stmt = $dbh -> prepare($sql);
        $data[] = $user_name;
        $stmt -> execute($data);
        
        $rec = $stmt -> fetch(PDO::FETCH_ASSOC);
        $uesr_id = $rec['user_id'];

        // SQLでreserveテーブルから予約データを取り出す
        $sql = 'SELECT res_id FROM reserve WHERE user_id=? AND res_seat=? AND res_date=? AND res_time=?';
        $stmt = $dbh -> prepare($sql);
        $data = array();
        $data[] = $user_id;
        $data[] = $select_seat;
        $data[] = $now_date;
        $data[] = $select_time;
        $stmt -> execute($data);

        $rec = $stmt -> fetch(PDO::FETCH_ASSOC);

        $sql = 'SELECT can_id FROM cancel WHERE user_id=? AND can_date=? AND can_time=?';
        $stmt2 = $dbh -> prepare($sql);
        $data = array();
        $data[] = $user_id;
        $data[] = $now_date;
        $data[] = $select_time;
        $stmt2 -> execute($data);

        $rec2 = $stmt2 -> fetchAll(PDO::FETCH_ASSOC);



        // 予約データがあるか判定
        if(isset($rec['res_id'])){
            $res_id = $rec['res_id'];

            // 予約データベースとキャンセル待ちデータベースをロック
            $sql = 'LOCK TABLES reserve WRITE,cancel WRITE';
            $stmt = $dbh -> prepare($sql);
            $stmt -> execute();

            // 指定の予約データ削除
            $sql = 'DELETE FROM reserve WHERE res_id=?';
            $stmt = $dbh -> prepare($sql);
            $data2[] = $res_id;
            $stmt -> execute($data2);


            // 該当するキャンセル待ちデータを検索
            $sql = 'SELECT can_id, user_id FROM cancel WHERE can_date=? AND can_time=? AND comp=0 ORDER BY can_id ASC LIMIT 1';
            $stmt2 = $dbh -> prepare($sql);
            $data = array();
            $data[] = $now_date;
            $data[] = $select_time;
            $stmt2 -> execute($data);
    
            $rec2 = $stmt2 -> fetch(PDO::FETCH_ASSOC);

            // 該当データがあればキャンセル待ちデータを予約データに挿入
            if(isset($rec2['user_id'])){
                $sql = 'INSERT INTO reserve(user_id, res_seat, res_date, res_time, res_yn) VALUES(?, ?, ?, ?, ?)';
                $stmt = $dbh -> prepare($sql);
                $data = array();
                $data[] = $rec2['user_id'];
                $data[] = $select_seat;
                $data[] = $now_date;
                $data[] = $select_time;
                $data[] = 'yes';

                $stmt -> execute($data);

                // キャンセル待ちデータのcomp(処理済み)の値を0→1にする
                $sql = 'UPDATE cancel SET comp=1 WHERE can_id=?';
                $stmt = $dbh -> prepare($sql);
                $data = array();
                $data[] = $rec2['can_id'];

                $stmt -> execute($data);

                // echo 'キャンセル待ち予約の処理した';
            }
            // LOCK解除
            $sql = 'UNLOCK TABLES';
            $stmt = $dbh -> prepare($sql);
            $stmt -> execute();

            // キャンセル完了を表示
            $can_comp=
            '<h3>'.
            '以下の内容の予約キャンセルが完了しました。'.
            '</h3>'.
            '<h2>'.
            $select_year .'年'.
            $select_month .'月'.
            $select_day .'日'.
            $select_time .' 発'.
            '<br>'.
            '座席番号:' .$select_seat.
            '<br>'.
            '</h2>';
        // }elseif(isset($rec10['res_id'])){

        
        } else {
            // 指定した予約が無ければ以下のメッセージを表示
            $can_no_res_seat=
            '該当する予約はありません。'.
            '<br><br>';
        }

        $dbh = null;
    }
    catch(Exception $e)
    {
        print 'ただいまご迷惑をお掛けしております。';
        print $e;
        exit();
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>キャンセル完了画面</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
    	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .form {
                width: auto;
                background: #fdfdfd;
                opacity: 0.95;
                padding-left: 30px;
                padding-right: 30px;            
                padding-top: 20px;
                padding-bottom: 20px;
                border-radius: 20px;
                box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
                text-align: center;
            }
            label {
                color:black;
            }
            table {
              color: black;
            }
            table td, table th {
                color: black;
            }
            h1{
                text-align: center;
            }
            .links{
                text-align: right;
            }
            h3,h2,a{
            color:black;
            }
            /* body {
                margin-left: 400px;
                margin-right: 400px;
                padding: 50px;
            } */
            .link {
                text-align: right;
            }
            </style>
                <header>  
        <p>キャンセル完了画面</p> 
    </header>
    <br><br>
    <body class="all">
    <div class="form-container">
        <div class="form">
            <label>
    <?php
        if (isset($can_comp) && $can_comp !== '') {
            echo $can_comp;
        }
        if (isset($can_no_res_seat) && $can_no_res_seat !== '') {
            echo $can_no_res_seat;
        }
    ?>
        <a href="res_status.php">座席状況に戻る</a>
               </label>
            </div>
		</div>
    </body>
</html>