<?php
    //ローカル環境でのテストではログインチェックのセッションをコメントアウト
    session_start();
    session_regenerate_id(true);
    require_once('../common/common.php'); 
    login_check();

    //ローカル環境でのテストでは管理者ネームとユーザーネームのセッションをコメントアウト
    if(isset($_SESSION['admin_login'])==true){
        $admin_name = $_SESSION['admin_name'];
        $user_name = $_SESSION['user_name'];
    }else{
        $user_name = $_SESSION['user_name'];
    }
    
    // ローカル環境では下記をコメントアウト
    $select_year = $_SESSION['select_year'];
    $select_month = $_SESSION['select_month'];
    $select_day = $_SESSION['select_day'];
    $select_time = $_SESSION['select_time'];

    // // ローカル環境でのテストのため仮の値を代入
    // $select_year = '2023';
    // $select_month = '06';
    // $select_day = '23';
    // $select_time = '08:10:00';
    // $user_name = 'hanachan';

    ?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>キャンセル待ち予約完了画面</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
    	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .form {
                width: auto;
                background: #fdfdfd;
                opacity: 0.95;
                padding-left: 30px;
                padding-right: 30px;            
                padding-top: 20px;
                padding-bottom: 20px;
                border-radius: 20px;
                box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
                text-align: center;
            }
            label {
                color:black;
            }
            table {
              color: black;
            }
            table td, table th {
                color: black;
            }
            h1{
                text-align: center;
            }
            .links{
                text-align: right;
            }
            h3,h2,a{
            color:black;
            }
            /* body {
                margin-left: 400px;
                margin-right: 400px;
                padding: 50px;
            } */
            .link {
                text-align: right;
            }
            </style>
                <header>  
        <p>キャンセル待ち予約完了画面</p> 
    </header>
    <br><br>
    <body class="all">
    <div class="form-container">
        <div class="form">
            <label>
        <?php

            try{

                // データベースに接続する
                $dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
                $user = 'root';
                $password = '';
                $dbh = new PDO($dsn,$user,$password);
                $dbh -> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

                // SQL文で指令を出す
                // データベースuser_infoテーブルからuser_nameの値を指定してuser_idの値を取り出す
                $sql = 'SELECT user_id FROM user_info WHERE user_name=?';
                $stmt = $dbh->prepare($sql);
                $data[] = $user_name;
                $stmt -> execute($data);

                // $stmtからレコードを取り出し、変数$user_idに代入する
                $rec = $stmt -> fetch(PDO::FETCH_ASSOC);
                $user_id = $rec['user_id'];
                
                // テーブルにロックをかける
                $sql = 'LOCK TABLES cancel WRITE';
                $stmt = $dbh -> prepare($sql);
                $stmt -> execute();

                // キャンセル待ち予約をデータベースに登録する
                $sql = 'INSERT INTO cancel(user_id,can_date,can_time,comp) VALUES(?,?,?,?)';
                $stmt = $dbh -> prepare($sql);
                $data = array();
                $data[] = $user_id;
                $data[] = $select_year.$select_month.$select_day;
                $data[] = $select_time;
                // 初期値を0で登録
                $data[] = 0;
                $stmt -> execute($data);

                // テーブルのロックを解除する
                $sql = 'UNLOCK TABLES';
                $stmt = $dbh -> prepare($sql);
                $stmt -> execute();

                // データベースを切断する
                $dbh = null;                

            }catch(Exception $e){
                print 'ただいまご迷惑をお掛けしております。';
                print $e;
                exit();
            }

            // // ログイン名、管理者メニューへの遷移ボタン、ログアウト遷移ボタンを表示する
            // // ローカル環境でのみ使用
            // print '<div class="links">';
            // if(isset($admin_name)==true){
            //     print '管理者：'.$admin_name;
            //     print '　　';
            //     print '<a href="../admin_top.php" id="admin">管理者ページ</a>';
            //     print '<br />';
            // }else{
            //     print '<br />';
            //     print $user_name.'さんログイン中';
            // }
            // print '　　';
            // print '<a href="../logout.php" id="logout">ログアウト</a>';
            // print '</div>'
            // // ローカル環境ここまで

        ?>

        <!-- 完了画面を出力する -->
        <h3>
        以下の内容でキャンセル待ち予約が完了しました。
        </h3>
        <h2>
        <?php print $select_year ?>年
        <?php print $select_month ?>月
        <?php print $select_day ?>日
        <?php print substr($select_time, 0, 5) ?>　発
        </h2>

        <a href="res_status.php">座席状況に戻る</a>
        
    </body>
</html>