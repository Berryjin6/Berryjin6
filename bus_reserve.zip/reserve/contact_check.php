<?php
    //ローカル環境でのテストではログインチェックのセッションをコメントアウト
    session_start();
    session_regenerate_id(true);
    require_once('../common/common.php'); 
    login_check();//ログイン・ログアウトのリンクを表示する関数

    //ローカル環境でのテストでは管理者ネームとユーザーネームのセッションをコメントアウト
    // if(isset($_SESSION['admin_login'])==true){
    //     $admin_name = $_SESSION['admin_name'];
    // }else{
        $user_name = $_SESSION['user_name'];
    // }

    // // テスト用に$user_nameを代入
    // // テスト用にローカル環境で下記のSQL文でデータベースに追加
    // // INSERT INTO user_info(user_name,user_pass,name,admission,mail) 
    // //   VALUES("hanachan","hapo","ポリテク花子","4","hanako@poly.com")
    // $user_name = 'hanachan';


    try{

        require_once('../common/common.php'); 

        // 送信されたデータを無害化してから受け取る
        // sanitize（無害化したい値（配列））
        $post = sanitize($_POST);
        $con_class = $post['con_class'];
        $con_text = $post['con_text'];

        // データベースに接続する
        $dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
        $user = 'root';
        $password = '';
        $dbh = new PDO($dsn,$user,$password);
        $dbh -> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

        // SQL文で指令を出す
        // データベースuser_infoテーブルからuser_name'hanachan'のmailの値を取り出す
        $sql = 'SELECT mail FROM user_info WHERE user_name=?';
        $stmt = $dbh->prepare($sql);
        $data[] = $user_name;
        $stmt -> execute($data);

        // $stmtからレコードを取り出し、変数$mailに代入する
        $rec = $stmt -> fetch(PDO::FETCH_ASSOC);
        if($rec !== false){
            $mail = $rec['mail'];
        }

        // データベースを切断する
        $dbh = null;                

    }catch(Exception $e){
        print 'ただいまご迷惑をお掛けしております。';
        print $e;
        exit();
    }

    // // ログイン名、管理者メニューへの遷移ボタン、ログアウト遷移ボタンを表示する
    // // ローカル環境でのみ使用
    // print '<div class="links">';
    // if(isset($admin_name)==true){
    //     print '管理者：'.$admin_name;
    //     print '　　';
    //     print '<a href="../admin_top.php">管理者ページ</a>';
    //     print '<br />';
    // }else{
    //     print '<br />';
    //     print $user_name.'さんログイン中';
    // }
    // print '　　';
    // print '<a href="../logout.php">ログアウト</a>';
    // print '</div>'
    // // ローカル環境ここまで
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>お問い合わせ内容確認画面</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
	    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .margin{
                margin-left: 140px;
            }
            .form {
                width: auto;
                background: #fdfdfd;
                opacity: 0.95;
                padding-left: 30px;
                padding-right: 30px;
                padding-bottom: 10px;
                border-radius: 20px;
                box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
            }
            /* body{
                margin-left: 400px;
                margin-right: 400px;          
                padding:50px;          
            } */
            h1{
                text-align: center;
                color:black;
            }
            .link{
                text-align: right;
            }
        </style>
    </head>
    <body class="all">
        <header>
            <!-- <h1 id="title">お問い合わせ</h1> -->
            <p>お問い合わせ</p>
        </header>
        <br />
        <br />
        <div class="form-container">
			<div class="form">
				<label>
<?php   
 if(isset($_POST['con_text']) == false || $_POST['con_text'] == ''){
        print 'お問い合わせ内容がありません<br/>';
        echo '<button>';
        print '<a href="contact.php">戻る</a>';
        echo '</button>　　　　　　　　　　　　　　';
        exit();
    }
?>
                    <!-- 確認内容を画面へ出力する -->
                    <h2>お問い合わせ内容確認</h2>
                    ・お問い合わせ入力ユーザー<br />
                    <?php print '「'.$user_name.'」' ?>
                    <br /><br />
                    ・連絡先メールアドレス<br />
                    <?php print '「'.$mail.'」' ?>
                    <br /><br />
                    ・お問い合わせ分類<br />
                    <?php print '「'.$con_class.'」' ?>
                    <br /><br />
                    ・お問い合わせ内容<br />
                    <?php print '「'.$con_text.'」' ?>
                    <br /><br />
                    <!-- <button>
                    <a href="contact.php">戻る</a>
                    </button>　　　　　　　　　　 -->
        
                    <!-- 送信先へデータを引き渡す -->
                    <form method="post" action="contact_done.php">
                        <input type="hidden" name="user_name" value="<?php print $user_name ?>">
                        <input type="hidden" name="mail" value="<?php print $mail ?>">
                        <input type="hidden" name="con_class" value="<?php print $con_class ?>">
                        <input type="hidden" name="con_text" value="<?php print $con_text ?>">
                        <button>
                        <a href="../reserve/contact.php">戻る</a>
                        </button>　　　　　　　　　　　　　　
                        <button type="submit">送信</button>            
                    </form>
                </label>
            </div>
        </div>
    </body>
</html>