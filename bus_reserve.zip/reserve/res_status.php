<?php
    session_start();
    session_regenerate_id(true);
    // $_SESSION['admin_login'] = 1;
    // $_SESSION['admin_id'] = 1;
    // $_SESSION['admin_name'] = 'admin';
    // $_SESSION['user_login'] = 1;
    // $_SESSION['user_id'] = 1;
    // $_SESSION['user_name'] = 'username';

    require_once('../common/common.php');

    $dsn = 'mysql:dbname=bus; host=localhost; charset=utf8';
    $user = 'root';
    $password = '';
    $dbh = new PDO($dsn, $user, $password);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if(isset($_POST['user_name'])){
        $select_user_name = $_POST['user_name'];

        $sql = 'SELECT user_id, user_name FROM user_info WHERE user_name=?';
        $stmt = $dbh -> prepare($sql);
        $data[] = $select_user_name;
        $stmt -> execute($data);

        $rec = $stmt -> fetch(PDO::FETCH_ASSOC);
        $_SESSION['user_login'] = 1;
        $_SESSION['user_id'] = $rec['user_id'];
        $_SESSION['user_name'] = $rec['user_name'];
    };

    login_check();

    echo '<a href="../user_menu/user_reference.php">登録者情報</a><br/>';
    echo '<a href="contact.php">お問い合わせ</a><br/>';
    echo '<h2>予約状況</h2>';

    user_reserve();
    user_can_reserve();

    $nowDateTime = new DateTime();
    $now_set = $nowDateTime -> format('Y-m-d');

    echo '<br/><form id="start" method="post" action="branch.php">';
        select_action();
        // echo "<input type='date' name='date_time' value='{$now_set}'>";
        select_year();
        select_month();
        select_day();
        select_time();
        // select_seat();

        print'　　<input type="submit" value="送信">';
        echo '<input id="seatnum" type="hidden" name="select_seat" value="">';
    echo '</form>';

    echo '<br>※座席イメージ';
    echo '<table id="bus_seat" border="1" style="background-color:white"></table>';
    echo '<br>';
    echo '<input type="button" onclick="history.back()" value="戻る">';
    echo '<hr>';
    echo '<h2>座席予約状況</h2>';
    echo '<div>空き：<span style="border:solid 1px; background-color:white">　</span>　';
    echo '予約あり：<span style="background-color:black">　</span></div><br><br>';

    that_day();

    $dbh = null;
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>座席状況</title>
        <style>
            body{
                background-color: #dfffff;
            }
            #bus_seat{
                width: 300px;
                height: 200px;
                text-align: center;
            }
            #bus{
                width: 300px;
                height: 200px;
            }
            .bus{
                width: 50px;
                height: 40px;
                background-color: "black";
            }
            table[border="1"] .not{
                border: 1px solid white;
            }
            table .black, table .black_week{
                background-color: black;
            }
            #driver, #seat_1, #seat_2, #seat_3, #seat_4, .seat_num{
                width: 75px;
            }
            .week_seat{
                margin: 0 10px 5px 0;
                float: left;
            }
            .logout{
                text-align:right;
            }
        </style>
    </head>
    <body>
        <script src="../common/jquery-3.4.1.min.js"></script>
        <script src="../common/common.js"></script>
        <script>
            'use strict'

            bus_table();

            // 数字（<td>内）の要素の取得
            let trip = document.querySelectorAll('td');
    
            //表内の数字をクリックしたときの動き
            trip.forEach(function(page, index){
                page.onclick = function(){
                    if($(this).text() <= 9 && $(this).text() >= 1){
                        $('#seatnum').val($(this).text());
                        if($('.black').text() != $('#seatnum').val()){
                            $('.black').toggleClass('black');
                            $(this).toggleClass('black');
                        }else{
                            $(this).toggleClass('black');
                            $('#seatnum').val('');
                        }
                        // console.log($('.black').text());

                    }
                    // switch($(this).text()){
                    //     case 7 :
                    //     $(this).toggleClass('not');
                    // };

                    // console.log($(this).text());
                };

            });        
                // $('#start').submit(function(){
                //     event.preventDefault();
                //     $.post('branch.php',{seat:3});
                //     // let seat = $(this).text();

                //     // console.log($(this).text());
                // });

                // fetch('branch.php',{method:'POST', })
        </script>
    </body>
</html>
