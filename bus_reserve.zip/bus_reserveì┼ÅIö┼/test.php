<?php
 print md5('pass');
?>