function bus_table(){
    let num1 = [];
    let ta1 = 1;
    let i2 = 1;
    //表の枠生成(4x4)
    for( ta1 = 1; ta1 <= 4; ta1++){
        let array = `<tr id="array${ta1}">`
            $('#bus_seat').append(array)
    };

    //数字を<table>内に挿入    
    for(ta1 = 1; ta1 <= 16; ta1++){
        let li = `<td id="seat_${ta1-1}">${ta1-1}`;
        let li2 = `<td id="driver" rowspan="2">運転席`;
        let li3 = `<td id="seat_${ta1-2}">${ta1-2}`;
        
        if(ta1 > 8){
            switch(ta1){
                case 12:
                    li3 = `<td id="seat_${ta1-2}">${ta1-5}`;
                    break;

                case 13:
                    li3 = `<td id="seat_${ta1-2}">${ta1-5}`;
                    break;

                case 16:
                    li3 = `<td id="seat_${ta1-2}">${ta1-7}`;
                    break;
            }

            if(parseInt(ta1) % 4 !== 0){
                $(`#array${i2}`).append(li3);
            }else if(parseInt(ta1) % 4 === 0){
                if(ta1 !== 8){
                $(`#array${i2}`).append(li3);
                };
                i2++;
            };
        }else{
            if(ta1 === 1){
                $(`#array${i2}`).append(li2);
            }else if(parseInt(ta1) % 4 !== 0){
                $(`#array${i2}`).append(li);
            }else if(parseInt(ta1) % 4 === 0){
                if(ta1 !== 8){
                $(`#array${i2}`).append(li);
                };
                i2++;
            };

        }
    };

    for(let i = 1; i <= 16; i++){
        switch(i){
            case 7:
                $(`#seat_${i}`).addClass('not');
                $(`#seat_${i}`).text('　');
                break;

            case 8:
                $(`#seat_${i}`).addClass('not');
                $(`#seat_${i}`).text('　');
                break;

            case 9:
                $(`#seat_${i}`).addClass('not');
                $(`#seat_${i}`).text('　');
                break;

            case 12:
                $(`#seat_${i}`).addClass('not');
                $(`#seat_${i}`).text('　');
                break;

            case 13:
                $(`#seat_${i}`).addClass('not');
                $(`#seat_${i}`).text('　');
                break;
            
            default:
                break;
        };
    };
};