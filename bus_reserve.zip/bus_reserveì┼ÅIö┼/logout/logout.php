<?php
session_start();
$_SESSION=array();
if(isset($_COOKIE[session_name()])==true)
{
    setcookie(session_name(),'',time()-42000,'/');
}
session_destroy();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>ログアウト画面</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
    	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
		.form {
			width: auto;
			background: #fdfdfd;
			opacity: 0.95;
			padding-left: 30px;
			padding-right: 30px;            
			padding-bottom: 30px;
			border-radius: 20px;
			box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
            text-align:center;
        }
        button{
            color:white;
        }
	    </style>
    </head>

    <body class="all">
        <header>
            <p>ログアウト完了</p>
        </header>
        <br><br>
        <div class="form-container">
            <div class="form">
                <label>
                    <br>
                    ログアウトしました。<br><br>
                    ご利用ありがとうございました。<br>
                    またのご利用をお待ちしております。
                    <br><br>
                    <button>
                        <a href="../logout/login.html">トップページへ</a>
                    </button>
                </label>
            </div>
		</div>
    </body>
</html>



