<?php 
    session_start();
    //$_SESSION['admin_login']=1;//テスト用 
    if($_SESSION['admin_login']!=1){
        header('Location:../logout/login.html');
        exit();
    }
?>
<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
        <title>管理者ページ</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
    	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
		.form {
			width: auto;
			background: #fdfdfd;
			opacity: 0.95;
			padding-left: 30px;
			padding-right: 30px;            
			padding-bottom: 10px;
			border-radius: 20px;
			box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
        }
        a {
            color:black;
        }
        button{
            color:white;
        }
        .white{
            color:white;
        }
	    </style>
    </head>
    <body class="all">
    <header>
            <p>管理者画面</p>
        </header>
        <br><br>
        <div class="form-container">
			<div class="form">
				<label>
                    <br>
                    <a href="../login/signup.html ">●利用者登録</a><br><br>
                    <a href="../admin_menu/can_res_view.php">●キャンセル待ちデータ表示</a><br><br>
                    <a href="../admin_menu/contact_data.php">●問い合わせデータ表示</a><br><br>
                    <a href="../admin_menu/user_list.php">●利用者リスト表示</a><br><br>
                    <a href="../admin_menu/res_status_all.php">●座席状況(週間)</a><br><br>
                    <a href="../logout/logout.php">●ログアウト</a><br><br>
                    <button type="button" onclick="history.back()">戻る</button>
                    <!-- <button>
                        <a href="../login/logout.php">
                            <div class="white">
                                ログアウト
                            </div>
                        </a>
                    </button> -->

                </label>
            </div>
		</div>
    </body>
</html>