<?php
    function sanitize($before)
    {
        foreach($before as $key => $value)
        {
            $after[$key] = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
        }
        return $after;
    }

    try
    {
        $post = sanitize($_POST);
        $name = $post['name'];
        $pass = $post['pass'];
        
    //bus DB
        $dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
        $user = 'root';
        $password = '';
        $dbh = new PDO($dsn, $user, $password);
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        
    //管理者テーブル
        $sql = 'SELECT * FROM admin WHERE admin_name=? AND admin_pass=?';
        $stmt = $dbh->prepare($sql);
        $data = array();
        $data[] = $name;
        $data[] = md5($pass);
        $stmt->execute($data);
        $rec1 = $stmt->fetch(PDO::FETCH_ASSOC);


    //利用者テーブル
        $sql = 'SELECT * FROM user_info WHERE user_name=? AND user_pass=?';
        $stmt = $dbh->prepare($sql);
        $data = array();
        $data[] = $name;
        $data[] = md5($pass);
        $stmt->execute($data);
        $rec2 = $stmt->fetch(PDO::FETCH_ASSOC);

        $dbh = null;
        // var_dump($rec1);
        // var_dump($rec2);

        if (!empty($rec1))
        {
            // echo '管理者';
            session_start();
            session_regenerate_id(true);
            $_SESSION['admin_login'] = 1;
            $_SESSION['admin_code']=$pass;
            $_SESSION['admin_name'] = $rec1['admin_name'];
            // 管理者页面
            header('Location:../logout/admin_top.php'); 
        
            // echo'<a href="signup.html"></a>';
            // header('Location: signup2.html'); 
            exit();
        }
        elseif (!empty($rec2))
        {
            // echo '利用者';
            session_start();
            session_regenerate_id(true);
            $_SESSION['user_login'] = 1;
            $_SESSION['user_pass']=$pass;
            $_SESSION['user_name'] = $rec2['user_name'];
            // 会员页面
            header('Location:../reserve/res_status.php'); 
            
            // echo'<a href="signup.html"></a>';
            // header('Location: signup.html'); 

            exit();
        
        }
        else
        {
            $login_false = '<div class="form-container">'.
            '<div class="form">'.
            '<label>'.
            'ログインに失敗しました。<br /><br>'.
            'ユーザー名、またはパスワードが正しくありません。<br><br>'.
            '<button>'.
            '<a href="../logout/login.html">戻る</a>'.
            '</button>'.
            '</label>'.
            '</div>'.
            '</div>';
    
        }
    }
    catch(Exception $e)
    {
        echo 'ただいま障害により大変ご迷惑をお掛けしております。';
        exit();
    }

?> 
<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8"><!--要素一：文字コード-->
        <title>ログインチェック画面</title><!--要素二：ページのタイトルを指定-->
        <!-- <link rel="stylesheet" type="text/css" href="../common/common.css">2.要素三：CSSの読み込み -->
        <link rel="stylesheet" type="text/css" href="../common/common.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<style>
			.margin{
				margin-left: 30px;
			}
			.form {
				width: 400px;
				background: #fdfdfd;
				opacity: 0.95;
				padding-left: 30px;
				padding-bottom: 10px;
				border-radius: 20px;
				box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
                text-align:center;
			}
		</style>
    </head>
    <body class="all">
    <header>
        <p>ログインチェック画面</p>
    </header>
    <?php
        echo '<br><br>';
        echo $login_false;
        ?>
    </body>
</html>