<?php
    session_start();
    session_regenerate_id(true);

    require_once('../common/common.php'); 
    login_check();

    // 変数代入
    $select_year = $_SESSION['select_year'];
    $select_month = $_SESSION['select_month'];
    $select_day = $_SESSION['select_day'];
    $select_time = $_SESSION['select_time'];
    $select_seat = $_SESSION['select_seat'];
    $user_name = $_SESSION['user_name'];

    try{
        $now_date = "{$select_year}-{$select_month}-{$select_day}";

        // $n_datetime = new DateTime($now_date);
        // $nf_datetime = $n_datetime -> format("Y-m-d");

        //bus DB接続
        $dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
        $user = 'root';
        $password = '';
        $dbh = new PDO($dsn,$user,$password);
        $dbh -> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

        //ログイン中のuser_nameで、user_idを取得
        $sql = 'SELECT user_id FROM user_info WHERE user_name=?';
        $stmt = $dbh->prepare($sql);
        $data[] = $user_name;
        $stmt -> execute($data);

        //user_infoテーブルからレコードを取り出し、変数$user_idを代入
        $rec = $stmt->fetch(PDO::FETCH_ASSOC);
        $user_id = $rec['user_id'];
        
        // ロックをかける
        $sql = 'LOCK TABLES reserve WRITE';
        $stmt = $dbh->prepare($sql);
        $stmt -> execute();

        // 予約データをデータベースに登録する
        $sql = 'INSERT INTO reserve(user_id, res_seat, res_date, res_time, res_yn) VALUES(?, ?, ?, ?, ?)';
        $stmt = $dbh->prepare($sql);
        $data = array();
        $data[] = $user_id;
        $data[] = $select_seat;
        $data[] = $now_date;
        $data[] = $select_time;
        // 初期値yes
        $data[] = 'yes';
        $stmt -> execute($data);

        //ロック解除
        $sql = 'UNLOCK TABLES';
        $stmt = $dbh -> prepare($sql);
        $stmt -> execute();

        //DB閉じる
        $dbh = null;                

    }catch(Exception $e){
        print 'ただいまご迷惑をお掛けしております。';
        exit();
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>座席予約完了画面</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
    	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .form {
                width: auto;
                background: #fdfdfd;
                opacity: 0.95;
                padding-left: 30px;
                padding-right: 30px;            
                padding-top: 30px;
                padding-bottom: 30px;
                border-radius: 20px;
                box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
            }
            a {
            width: auto;
            border-radius: 5px;
            color: black;
            }
            .center{
                text-align:center;
                color:black;
            }
            button{
                color:white;
                text-align:center;
            }
            .white{
                color:white;
            }
            .center{
                text-align:center;
                color:black;
            }
            h3{
                color:black;
            }
            h2{
                color:black;
            }
	    </style>
    </head>
    <body class="all">
    <header>
        <p>予約完了画面</p>
    </header>
    <br><br>
        <div class="form-container">
			<div class="form">
				<label>
                    <div class="center">
                        <h3>以下の内容で予約が完了しました。</h3>
                        <br />
                        <h2>
                            <?php print $select_year ?>年
                            <?php print $select_month ?>月
                            <?php print $select_day ?>日
                            <?php print substr($select_time, 0, 5) ?> 発
                            <br /><br />
                            座席番号：<?php print $select_seat ?>
                            <br /><br />
                        </h2>
                        <button onclick="location.href='res_status.php'">座席状況に戻る</button>
                    </div>
                </label>
            </div>
		</div>  
    </body>
</html>