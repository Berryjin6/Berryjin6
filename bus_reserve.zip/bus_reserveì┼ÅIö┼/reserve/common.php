<?php
    function sanitize($before){
        foreach($before as $key => $value){
            $after[$key] = htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); 
        }

        return($after);
    }

    function login_check(){
        if(isset($_SESSION['admin_login'])){
            print '管理者：'.$_SESSION['admin_name'];
            print '<br/>';
            if(isset($_SESSION['user_login'])){
                print $_SESSION['user_name'].'でログイン中　　';
                print '<a href="logout.php">ログアウト</a><br/>';
            }else{
                print 'ユーザーが選択されていません。<br/>';
                print '<a href="admin_top.php">管理者ページへ</a><br/>';
                exit();
            }
            print '<a href="admin_top.php">管理者ページへ</a><br/>';
        } else{
            if(isset($_SESSION['user_login'])){
                print $_SESSION['user_name'].'さんログイン中';
                print '<a href="logout.php">ログアウト</a><br/>';
            }else{
                print 'ログインされていません。<br/>';
                print '<a href="login.html">ログイン画面へ</a>';
                exit();
            }
        }
    }

    function login_check_admin(){
        if(isset($_SESSION['admin_login'])){
                print '管理者：'.$_SESSION['admin_name'];
                print '　　<a href="logout.php">ログアウト</a><br/>';
                print '<a href="admin_top.php">管理者ページへ</a><br/>';
            }else{
                print 'ログインされていません。<br/>';
                print '<a href="login.html">ログイン画面へ</a>';
                exit();
            }
        }

    function user_reserve(){
        $dsn = 'mysql:dbname=bus; host=localhost; charset=utf8';
        $user = 'root';
        $password = '';
        $dbh = new PDO($dsn, $user, $password);
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
        $sql = 'SELECT res_time FROM reserve WHERE user_id=?';
        $stmt = $dbh -> prepare($sql);
        $data[] = $_SESSION['user_id'];
        $stmt -> execute($data);
        $rec = $stmt -> fetchAll(PDO::FETCH_ASSOC);
        $c_rec = count($rec);
    
        if(count($rec) > 0){
            echo '予約済み座席<br>';
            echo "<table border='1'>";

            $sql = 'SELECT res_seat, res_date, res_time, res_yn FROM reserve WHERE user_id=?';
            $stmt = $dbh -> prepare($sql);
            $data = [];
            $data[] = $_SESSION['user_id'];
            $stmt -> execute($data);

            while(true){
                $rec = $stmt -> fetch(PDO::FETCH_ASSOC);
                if(!$rec){
                    break;
                }
                $year = substr($rec['res_date'], 0, 4);
                $month = substr($rec['res_date'], 5, 2);
                $day = substr($rec['res_date'], 8, 2);
                $hors = substr($rec['res_time'], 0, 2);
                $second = substr($rec['res_time'], 3, 2);
                $seat = $rec['res_seat'];

                echo "<td>{$month}月{$day}日</td><td>{$hors}：{$second}</td><td>座席番号：{$seat}番</td>";
            }

            echo "</table >";
        };
    }

    function select_action(){
        $action[] = '予約';
        $action[] = 'キャンセル';
        $action[] = 'キャンセル待ち予約';
        print '予約項目　';
        print '<select name="select_action">';
        foreach($action as $key => $val){
            print '<option value="'.$key.'">'.$val.'</option>';
        };
        print '</select>　　';
    }

    function select_year(){
        $nowDateTime = new DateTime();
        $n_year = $nowDateTime -> format('Y');

        print '<select name="select_year">';
        for($i = $n_year; $i <= $n_year + 1; $i++){
        print '<option value="'.$i.'">'.$i.'</option>';
        };
        print '</select>年';
    }

    function select_month(){
        print '<select name="select_month">';
        for($i = 1; $i < 13; $i++){
            print '<option value="'.sprintf('%02d',$i).'">'.sprintf('%02d',$i).'</option>';
        };
        print '</select>月';
    }

    function select_day(){
        print '<select name="select_day">';
        for($i = 1; $i <= 31; $i++){
            print '<option value="'.sprintf('%02d',$i).'">'.sprintf('%02d',$i).'</option>';
        };
        print '</select>日';
    }

    function select_time(){
        print '　　時刻　<select name="select_time">';
        for($i = 50,$s_hors = 7; $s_hors < 9; $i = $i + 10){
            if($i >= 60){
                $s_hors++;
                $i = 0;
            }

            if($s_hors !== 9){
                print '<option value="'.sprintf('%02d',$s_hors).':'.sprintf('%02d',$i).'">'.sprintf('%02d',$s_hors).'：'.sprintf('%02d',$i).'</option>';
            }
        };
        print '</select>　';
    }

    function select_seat(){
        print '座席番号：<select name="select_seat">';
        for($i = 1; $i <= 9; $i++){
            print '<option value="'.$i.'">'.$i.'</option>';
        };
        print '</select>';
    }

    function week_day($DoW){
        // 日:0  月:1  火:2  水:3  木:4  金:5  土:6
        $day_of_week[] = '日';
        $day_of_week[] = '月';
        $day_of_week[] = '火';
        $day_of_week[] = '水';
        $day_of_week[] = '木';
        $day_of_week[] = '金';
        $day_of_week[] = '土';
        return $day_of_week[$DoW];
    }

    function that_day(){
        $dsn = 'mysql:dbname=bus; host=localhost; charset=utf8';
        $user = 'root';
        $password = '';
        $dbh = new PDO($dsn, $user, $password);
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $nowDateTime = new DateTime();
        $n_year = $nowDateTime -> format('Y');
        $n_month = $nowDateTime -> format('m');
        $n_day = $nowDateTime -> format('d');

        if($nowDateTime -> format('H') >= 12){
            $n_day++;
        }

        $u = 1;
        $n_month_day[] = '0';
        $n_month_day[] = '0';

        echo "<span class='week_seat' style='background-color:white'>";
        for($i = 50,$s_hors = 7; $s_hors < 9; $i = $i + 10){
            $data = [];
            if($i >= 60){
                $s_hors++;
                $i = 0;
            }

            if($s_hors !== 9){
                $s_time = sprintf('%02d',$s_hors).':'.sprintf('%02d',$i);

                $sql = 'SELECT res_seat, res_time, res_yn FROM reserve WHERE substr(res_date, 1, 4)=? AND substr(res_date, 6, 2)=? AND substr(res_date, 9, 2)=? AND substr(res_time, 1, 5)=?';
                $stmt = $dbh -> prepare($sql);
                $data[] = $n_year;
                $data[] = $n_month;
                $data[] = $n_day;
                $data[] = $s_time;
                $stmt -> execute($data);

                $reserve =[];

                while(true){
                    $rec = $stmt -> fetch(PDO::FETCH_ASSOC);
                    if(!$rec){
                        break;
                    }

                    if($rec['res_seat'] > 0 && $rec['res_seat'] < 7){
                        $reserve[] = $rec['res_seat'] + 1;
                    }else{
                        switch($rec['res_seat']){
                            case 7:
                                $reserve[] = $rec['res_seat'] + 5;
                                break;

                            case 8:
                                $reserve[] = $rec['res_seat'] + 5;
                                break;

                            case 9:
                                $reserve[] = $rec['res_seat'] + 7;
                                break;

                            default:
                                break;
                        };
                    };
                };

                if($data[1] !== $n_month_day[0] || $data[2] !== $n_month_day[1]){
                    $n_date = "<span>".$data[1]."月".$data[2]."日</span>"."<br>";
                }else{
                    $n_date = '';
                };
                $datetime = $data[3];
                echo $n_date.$datetime;

                echo "<table id='over".$u."' class='flot' border='1'>";
                for($o = 1; $o <= 4; $o++){
                    $mess = '';
                    for($y = 1; $y <= 4; $y++){
                        $sum = $y + ($o - 1) * 4 ;
                        $not = '';
                        $yn = '';
                        if($sum != 8){
                            switch($sum){
                                case 9:
                                    $not = " not";
                                    break;

                                case 10:
                                    $not = " not";
                                    break;

                                case 11:
                                    $not = " not";
                                    break;

                                case 14:
                                    $not = " not";
                                    break;

                                case 15:
                                    $not = " not";
                                    break;
                            
                                default:
                                    break;

                            }
                        $s_num = array_search($sum, $reserve);
                        if($s_num !== false){
                            $yn = $reserve[$s_num] === $sum? ' black':'';
                        };

                        $drive = $sum === 1? '2':'1';
                        $value_mess = $sum === 1? '運転席':'　';
                        // $value_mess = $sum === 1? '運転席':$sum;
                        $mess .= "<td class='seat_num".$not.$yn." seat_num_".$sum."'rowspan='".$drive."'>{$value_mess}</td>";
                        }
                    }
                    $mess2 = "<tr>{$mess}</tr>";
                    echo $mess2;
                }
                echo "</table><br>";
                $u++;
                $n_month_day[0] = $data[1];
                $n_month_day[1] = $data[2];
            }            
        }
        echo "<br></span>";
    }

    function select_that_day(){
        $dsn = 'mysql:dbname=bus; host=localhost; charset=utf8';
        $user = 'root';
        $password = '';
        $dbh = new PDO($dsn, $user, $password);
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $post = sanitize($_POST);
        $sel_year = $post['select_year'];
        $sel_month = $post['select_month'];
        $sel_day = $post['select_day'];
    
        $sel_year_month_day = $sel_year.'-'.$sel_month.'-'.$sel_day;
        $nowDateTime = new DateTime($sel_year_month_day);
        
        $n_year = $nowDateTime -> format("Y");
        $n_month = $nowDateTime -> format("m");
        $n_day = $nowDateTime -> format("d");

        $u = 1;
        $n_month_day[] = '0';
        $n_month_day[] = '0';

        echo "<span class='week_seat' style='background-color:white'>";
        for($i = 50,$s_hors = 7; $s_hors < 9; $i = $i + 10){
            $data = [];
            if($i >= 60){
                $s_hors++;
                $i = 0;
            }

            if($s_hors !== 9){
                $s_time = sprintf('%02d',$s_hors).':'.sprintf('%02d',$i);

                $sql = 'SELECT res_seat, res_time, res_yn FROM reserve WHERE substr(res_date, 1, 4)=? AND substr(res_date, 6, 2)=? AND substr(res_date, 9, 2)=? AND substr(res_time, 1, 5)=?';
                $stmt = $dbh -> prepare($sql);
                $data[] = $n_year;
                $data[] = $n_month;
                $data[] = $n_day;
                $data[] = $s_time;
                $stmt -> execute($data);

                $reserve =[];

                while(true){
                    $rec = $stmt -> fetch(PDO::FETCH_ASSOC);
                    if(!$rec){
                        break;
                    }

                    if($rec['res_seat'] > 0 && $rec['res_seat'] < 7){
                        $reserve[] = $rec['res_seat'] + 1;
                    }else{
                        switch($rec['res_seat']){
                            case 7:
                                $reserve[] = $rec['res_seat'] + 5;
                                break;

                            case 8:
                                $reserve[] = $rec['res_seat'] + 5;
                                break;

                            case 9:
                                $reserve[] = $rec['res_seat'] + 7;
                                break;

                            default:
                                break;
                        };
                    };
                    if($rec['user_id'] > 0 ){
                        $sql2 = 'SELECT user_name FROM user_info WHERE user_id=?';
                        $stmt2 = $dbh -> prepare($sql2);
                        $set_id[] = $rec['user_id'];
                        $stmt2 -> execute($set_id);

                        $rec2 = $stmt2 -> fetch(PDO::FETCH_ASSOC);
                        $seat_user = $rec2['user_name'];
                    }
                };

                if($data[1] !== $n_month_day[0] || $data[2] !== $n_month_day[1]){
                    $n_date = "<span>".$data[0]."年".$data[1]."月".$data[2]."日</span>"."<br>";
                }else{
                    $n_date = '';
                };
                $datetime = $data[3];
                echo $n_date.$datetime;

                echo "<table id='over".$u."' class='flot' border='1'>";
                for($o = 1; $o <= 4; $o++){
                    $mess = '';
                    for($y = 1; $y <= 4; $y++){
                        $sum = $y + ($o - 1) * 4 ;
                        $not = '';
                        $yn = '';
                        if($sum != 8){
                            switch($sum){
                                case 9:
                                    $not = " not";
                                    break;

                                case 10:
                                    $not = " not";
                                    break;

                                case 11:
                                    $not = " not";
                                    break;

                                case 14:
                                    $not = " not";
                                    break;

                                case 15:
                                    $not = " not";
                                    break;
                            
                                default:
                                    break;

                            }
                        $s_num = array_search($sum, $reserve);
                        if($s_num !== false){
                            $yn = $reserve[$s_num] === $sum? $seat_user:'';
                        };

                        $drive = $sum === 1? '2':'1';
                        $value_mess = $sum === 1? '運転席':'　';
                        // $value_mess = $sum === 1? '運転席':$sum;
                        $mess .= "<td class='seat_num".$not." seat_num_".$sum."'rowspan='".$drive."'>{$value_mess}{$yn}</td>";
                        }
                    }
                    $mess2 = "<tr>{$mess}</tr>";
                    echo $mess2;
                }
                echo "</table><br>";
                $u++;
                $n_month_day[0] = $data[1];
                $n_month_day[1] = $data[2];
            }
        }
        echo "<br></span>";
    }

    function that_dayAll(){
        $dsn = 'mysql:dbname=bus; host=localhost; charset=utf8';
        $user = 'root';
        $password = '';
        $dbh = new PDO($dsn, $user, $password);
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $nowDateTime = new DateTime();

        if($nowDateTime -> format('H') <= 12){
            $nowDateTime -> modify('-1 days');
        }

        $u = 1;
        $n_month_day[] = '0';
        $n_month_day[] = '0';

        for($f = 1; $f <= 7; $f++){
            $nowDateTime -> modify('+1 days');
            $n_year = $nowDateTime -> format('Y');
            $n_month = $nowDateTime -> format('m');
            $n_day = $nowDateTime -> format('d');
            $w_d = $nowDateTime -> format("w");

            $d_o_w = week_day($w_d);
        

            echo "<span class='week_seat' style='background-color:white'>";
            for($i = 50,$s_hors = 7; $s_hors < 9; $i = $i + 10){
                $data = [];
                if($i >= 60){
                    $s_hors++;
                    $i = 0;
                }

                if($s_hors !== 9){
                    $s_time = sprintf('%02d',$s_hors).':'.sprintf('%02d',$i);

                    $sql = 'SELECT res_seat, res_time, res_yn FROM reserve WHERE substr(res_date, 1, 4)=? AND substr(res_date, 6, 2)=? AND substr(res_date, 9, 2)=? AND substr(res_time, 1, 5)=?';
                    $stmt = $dbh -> prepare($sql);
                    $data[] = $n_year;
                    $data[] = $n_month;
                    $data[] = $n_day;
                    // $data[] = "2023";
                    // $data[] = "06";
                    // $data[] = "28";
                    $data[] = $s_time;
                    $stmt -> execute($data);

                    $reserve =[];

                    while(true){
                        $rec = $stmt -> fetch(PDO::FETCH_ASSOC);
                        if(!$rec){
                            break;
                        }

                        if($rec['res_seat'] > 0 && $rec['res_seat'] < 7){
                            $reserve[] = $rec['res_seat'] + 1;
                        }else{
                            switch($rec['res_seat']){
                                case 7:
                                    $reserve[] = $rec['res_seat'] + 5;
                                    break;

                                case 8:
                                    $reserve[] = $rec['res_seat'] + 5;
                                    break;

                                case 9:
                                    $reserve[] = $rec['res_seat'] + 7;
                                    break;

                                default:
                                    break;
                            };
                        };
                    };

                    if($data[1] !== $n_month_day[0] || $data[2] !== $n_month_day[1]){
                        $n_date = "<span>".$data[1]."月".$data[2]."日(".$d_o_w.")</span>"."<br>";
                    }else{
                        $n_date = '';
                    };
                    $datetime = $data[3];
                    echo $n_date.$datetime;

                    echo "<table id='over".$u."' class='flot' border='1'>";
                    for($o = 1; $o <= 4; $o++){
                        $mess = '';
                        for($y = 1; $y <= 4; $y++){
                            $sum = $y + ($o - 1) * 4 ;
                            $not = '';
                            $yn = '';
                            if($sum != 8){
                                switch($sum){
                                    case 9:
                                        $not = " not";
                                        break;

                                    case 10:
                                        $not = " not";
                                        break;

                                    case 11:
                                        $not = " not";
                                        break;

                                    case 14:
                                        $not = " not";
                                        break;

                                    case 15:
                                        $not = " not";
                                        break;
                                
                                    default:
                                        break;

                                }
                            $s_num = array_search($sum, $reserve);
                            if($s_num !== false){
                                $yn = $reserve[$s_num] === $sum? ' black':'';
                            };

                            $drive = $sum === 1? '2':'1';
                            $value_mess = $sum === 1? '運転席':'　';
                            // $value_mess = $sum === 1? '運転席':$sum;
                            $mess .= "<td class='seat_num".$not.$yn." seat_num_".$sum."'rowspan='".$drive."'>{$value_mess}</td>";
                            }
                        }
                        $mess2 = "<tr>{$mess}</tr>";
                        echo $mess2;
                    }
                    echo "</table><br>";
                    $u++;
                    $n_month_day[0] = $data[1];
                    $n_month_day[1] = $data[2];
                }
            }
            echo "<br></span>";
        }
    }
?>
