<?php
    //ローカル環境でのテストではログインチェックのセッションをコメントアウト
    session_start();
    session_regenerate_id(true);
    require_once('../common/common.php'); 
    login_check();

    //ローカル環境でのテストでは管理者ネームとユーザーネームのセッションをコメントアウト
    // if(isset($_SESSION['admin_login'])==true){
    //     $admin_name = $_SESSION['admin_name'];
    // }else{
        $user_name = $_SESSION['user_name'];
    // }
    
    // ローカル環境でのテストでは下記をコメントアウト
    $select_year = $_SESSION['select_year'];
    $select_month = $_SESSION['select_month'];
    $select_day = $_SESSION['select_day'];
    $select_time = $_SESSION['select_time'];

    // ローカル環境でのテストのため仮の値を代入
    // $select_year = '2023';
    // $select_month = '06';
    // $select_day = '23';
    // $select_time = '08:10:00';
    // $user_name = 'hanachan';

    try{

        $now_datetime = $select_year.'-'.$select_month.'-'.$select_day;
        // 指定したバスにすでに予約されているか確認する
        // データベースに接続する
        $dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
        $user = 'root';
        $password = '';
        $dbh = new PDO($dsn,$user,$password);
        $dbh -> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

        // SQL文で指令を出す
        // データベースuser_infoテーブルからuser_nameの値を指定してuser_idの値を取り出す
        $sql = 'SELECT user_id FROM user_info WHERE user_name=?';
        $stmt = $dbh->prepare($sql);
        $data[] = $user_name;
        $stmt -> execute($data);

        // $stmtからレコードを取り出し、変数$user_idに代入する
        $rec = $stmt -> fetch(PDO::FETCH_ASSOC);
        $user_id = $rec['user_id'];

        // 指定日に予約が埋まっているか確認
        $sql = 'SELECT res_seat FROM reserve WHERE res_date=? AND res_time=?';
        $stmt2 = $dbh->prepare($sql);
        $data = array();
        $data[] = $select_year.'-'.$select_month.'-'.$select_day;
        $data[] = $select_time;
        $stmt2 -> execute($data);


        // シートの埋まり具合を確認
        $seat_num = [];
        while(true){
            $rec2 = $stmt2 -> fetch(PDO::FETCH_ASSOC);
            if($rec2 === false){
                break;
            }
            $seat_num[] = $rec2['res_seat'];
        }
        $open_seat = count($seat_num);

        if($open_seat >= 9){
            // SQL文で指令を出す
            // データベースreserveテーブルからuser_idとres_timeの値を指定してres_idの値を取り出す
            $sql = 'SELECT res_id FROM reserve WHERE user_id=? AND res_date=?';
            $stmt = $dbh->prepare($sql);
            $data = array();
            $data[] = $user_id;
            $data[] = $now_datetime;
            $stmt -> execute($data);

            // $stmtからレコードを取り出す
            $rec = $stmt -> fetch(PDO::FETCH_ASSOC);

            // 座席にすでに予約がある場合は座席状況へ戻るページへのリンクを表示する
            if(isset($rec['res_id'])==true){
                $seat_already_res = $user_name .
                    '様は同日のバスにすでに予約があります。<br />' .
                    '予約状況をご確認ください。<br />' .
                    '<br />' .
                    '<a href="res_status.php">座席状況へ戻る</a>';
            }
        }else{
            $already_empty='1';
        }

        


        // データベースを切断する
        $dbh = null;                

    }catch(Exception $e){
        print 'ただいまご迷惑をお掛けしております。';
        print $e;
        exit();
    }

    // // ログイン名、管理者メニューへの遷移ボタン、ログアウト遷移ボタンを表示する
    // // ローカル環境でのみ使用
    // print '<div class="links">';
    // if(isset($admin_name)==true){
    //     print '管理者：'.$admin_name;
    //     print '　　';
    //     print '<a href="../admin_top.php" id="admin">管理者ページ</a>';
    //     print '<br />';
    // }else{
    //     print '<br />';
    //     print $user_name.'さんログイン中';
    // }
    // print '　　';
    // print '<a href="../logout.php" id="logout">ログアウト</a>';
    // print '</div>'
    // // ローカル環境ここまで
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>キャンセル待ち予約確認画面</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
    	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
		.form {
			width: auto;
			background: #fdfdfd;
			opacity: 0.95;
			padding-left: 30px;
			padding-right: 30px;            
			padding-top: 30px;
			padding-bottom: 30px;
			border-radius: 20px;
			box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
            text-align:center;
        }
        a {
        width: auto;
        border-radius: 5px;
        color: black;
        }
        .center{
            text-align:center;
            color:black;
        }
        button{
            color:white;
            text-align:center;
        }
        .white{
            color:white;
        }
        .center{
            text-align:center;
            color:black;
        }
        h3{
            color:black;
        }
        h2{
            color:black;
        }
        /* body{
            margin-left: 400px;
            margin-right: 400px;          
            padding:50px;          
        } */
        h1{
            text-align: center;
        }
        .links{
            text-align: right;
        }
        </style>
    </head>
    <body class="all">
    <header>  
        <p>キャンセル確認画面</p> 
    </header>
		<br><br>
        <div class="form-container">
			<div class="form">
				<label>
    <?php
        if (isset($seat_already_res) && $seat_already_res !== '') {
            echo $seat_already_res;
            exit();
        }
        if (isset($already_empty) && $already_empty !== '') {
            $open_seat_num = '';
            for($i = 1; $i <= 9; $i++){
                if(array_search($i,$seat_num) === false){
                    $open_seat_num .= $i.'番　';
                }
            }
            echo $select_year.'年'.$select_month.'月'.$select_day.'日'.$select_time.'の便は<br>';
            echo $open_seat_num.'に空きがあります<br>';
            echo '<button>';
            echo '<a href="res_status.php">戻る</a>';
            echo '</button>';
            exit();
        }
    ?>

        <!-- 確認内容を画面へ出力する -->

        <h3>
        以下の内容でキャンセル待ち予約を実行します。<br>
        よろしいですか？
        </h3>

        <h2>
        <?php print $select_year ?>年
        <?php print $select_month ?>月
        <?php print $select_day ?>日
        <?php print substr($select_time, 0, 5) ?>　発
        </h2>
        <br />
        <button onclick="location.href='res_status.php'">戻る</button>　　
        <button onclick="location.href='can_res_done.php'">ＯＫ</button>
                </label>
            </div>
		</div>
    </body>
</html>