<?php
    //ローカル環境でのテストではログインチェックのセッションをコメントアウト
    session_start();
    session_regenerate_id(true);
    require_once('../common/common.php'); 
    login_check();

    //ローカル環境でのテストでは管理者ネームとユーザーネームのセッションをコメントアウト
    // if(isset($_SESSION['admin_login'])==true){
    //     $admin_name = $_SESSION['admin_name'];
    // }else{
        $user_name = $_SESSION['user_name'];
    // }

    try{

        require_once('../common/common.php'); 

        // 送信されたデータを無害化してから受け取る
        // sanitize（無害化したい値（配列））
        $post = sanitize($_POST);
        $user_name = $post['user_name'];
        $mail = $post['mail'];
        $con_class = $post['con_class'];
        $con_text = $post['con_text'];

        // データベースに接続する
        $dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
        $user = 'root';
        $password = '';
        $dbh = new PDO($dsn,$user,$password);
        $dbh -> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

        // テーブルにロックをかける
        $sql = 'LOCK TABLES contact WRITE';
        $stmt = $dbh -> prepare($sql);
        $stmt -> execute();

        // 問い合わせ内容をデータベースに登録する
        $sql = 'INSERT INTO contact(user_name,text,class,status) VALUES(?,?,?,?)';
        $stmt = $dbh -> prepare($sql);
        $data = array();
        $data[] = $user_name;
        $data[] = $con_text;
        $data[] = $con_class;
        // 初期値を0で登録
        $data[] = 0;
        $stmt -> execute($data);

        // テーブルのロックを解除する
        $sql = 'UNLOCK TABLES';
        $stmt = $dbh -> prepare($sql);
        $stmt -> execute();

        // データベースを切断する
        $dbh = null;                

    }catch(Exception $e){
        print 'ただいまご迷惑をお掛けしております。';
        print $e;
        exit();
    }

    // // ログイン名、管理者メニューへの遷移ボタン、ログアウト遷移ボタンを表示する
    // // ローカル環境でのみ使用
    // print '<div class="links">';
    // if(isset($admin_name)==true){
    //     print '管理者：'.$admin_name;
    //     print '　　';
    //     print '<a href="../admin_top.php" id="admin">管理者ページ</a>';
    //     print '<br />';
    // }else{
    //     print '<br />';
    //     print $user_name.'さんログイン中';
    // }
    // print '　　';
    // print '<a href="../logout.php" id="logout">ログアウト</a>';
    // print '</div>'
    // // ローカル環境ここまで
?>

<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
        <title>お問い合わせ内容送信完了</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
	    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .margin{
                margin-left: 140px;
            }
            .form {
                width: auto;
                background: #fdfdfd;
                opacity: 0.95;
                padding-left: 30px;
                padding-right: 30px;
                padding-bottom: 20px;
                border-radius: 20px;
                box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
            }
            /* body{
                margin-left: 400px;
                margin-right: 400px;          
                padding:50px;          
            } */
            h1{
                text-align: center;
                color:black;
            }
            .center{
                text-align: center;
                color:black;
            }
            .link{
                text-align: right;
            }
        </style>
    </head>
    <body class="all">
        <header>
            <!-- <h1 id="title">お問い合わせ</h1> -->
            <p>お問い合わせ内容送信完了</p>
        </header>
        <br />
        <br />
        <div class="form-container">
			<div class="form">
				<label>
        <!-- 確認内容を画面へ出力する -->
                    <br />
                    <div class="center">
                        <?php print $user_name ?>　様<br />
                        <br />
                        お問い合わせありがとうございました。<br />
                        回答は後日、下記メールアドレスへ管理者から<br>
                        メールでお知らせいたします。<br />
                        <br />
                        メールアドレス<br />
                        <?php print $mail ?>
                        <br /><br />
                        <button>
                            <a href="res_status.php">座席状況へ戻る</a>
                        </button>
                    </div>
                </label>
            </div>
        </div>
    </body>
</html>