<?php
    //ローカル環境でのテストではログインチェックのセッションをコメントアウト
    session_start();
    session_regenerate_id(true);
    require_once('../common/common.php'); 
    login_check();

    //ローカル環境でのテストでは管理者ネームとユーザーネームのセッションをコメントアウト
    if(isset($_SESSION['admin_login'])==true){
        $admin_name = $_SESSION['admin_name'];
    }else{
        $user_name = $_SESSION['user_name'];
    }

    // // テスト用では$user_nameを代入
    // $user_name = 'hanachan';
    
    // // ログイン名、管理者メニューへの遷移ボタン、ログアウト遷移ボタンを表示する
    // // ローカル環境でのみ使用
    // print '<div class="links">';
    // if(isset($admin_name)==true){
    //     print '管理者：'.$admin_name;
    //     print '　　';
    //     print '<a href="../admin_top.php" id="admin">管理者ページ</a>';
    //     print '<br />';
    // }else{
    //     print '<br />';
    //     print $user_name.'さんログイン中';
    // }
    // print '　　';
    // print '<a href="../logout.php" id="logout">ログアウト</a>';
    // print '</div>'
    // // ローカル環境ここまで
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>お問い合わせ</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .margin{
                margin-left: 140px;
            }
            .form {
                width: auto;
                background: #fdfdfd;
                opacity: 0.95;
                padding-left: 30px;
                padding-right: 30px;
                padding-bottom: 10px;
                border-radius: 20px;
                box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
            }
            /* body{
                margin-left: 400px;
                margin-right: 400px;          
                padding:50px;          
            } */
            select[name="con_class"], input[name="con_text"], a {
                color: black;
            }

            h1{
                text-align: center;
            }
            .link{
                text-align: right;
            }
            .txt{
                display: inline-block;
                width: 500px;
                height: 100px;
                /* padding: 1em 0.5em; */
                /* line-height: 4; */
                border: 1px solid #999;
                box-sizing: border-box;
                margin: 0.5em 0;
                color:black;
            }
            .submit{
                text-align: right;
                margin-right: 500px;
            }
            * {
                font-family: serif;
                color:black;
                box-sizing: border-box;
            }
            p{
                color:black;
            }
        </style>
    </head>
    <body class="all">
        <header>
            <p>お問い合わせ</p>
        </header>
        <br />
        <br />
        <div class="form-container">
			<div class="form">
				<label>
                    <form method="post" action="contact_check.php">
                        問い合わせ分類<br />
                        <select name="con_class" style="color: black; font-size: 20px; height: 35px;">
                            <option value="要望">要望</option>
                            <option value="運転について">運転について</option>
                            <option value="送迎時間について">送迎時間について</option>
                            <option value="その他">その他</option>
                        </select>
                        <br /><br />
                        お問い合わせ内容<br />
                        <textarea type="text" name="con_text" class="txt"></textarea>
                        <br /><br />
                        <button>
                        <a href="res_status.php">戻る</a>
                        </button>　　　　　　　　　　　　　　　　　　　　　
                        <button type="submit">送信</button>
                        <br />
                    </form>
                </label>
            </div>
        </div>
    </body>
</html>