<?php
	//以下、連結時にコメントアウト解除

	session_start();
	session_regenerate_id(true);
	require_once('../common/common.php');
	login_check();
	//  if(isset($_SESSION['admin_login'])==false)
	// {
	//  	print 'ログインされていません。<br />';
	// 	print '<a href="../staff_login/staff_login.html">ログイン画面へ</a>';
	// 	exit(); }
	//  else
	//  {
	//  	print $_SESSION['user_name'];
	// 	print 'さんログイン中<br />';
	//  	print '<br />';
	// }

	try{
		$user_name=$_SESSION['user_name'];

		$dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
		$user = 'root';
		$password = '';
		$dbh = new PDO($dsn, $user, $password);
		$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		$sql = 'SELECT name, user_pass, admission, mail FROM user_info WHERE user_name = ?';
		$stmt = $dbh->prepare($sql);
		$data[] = $user_name;
		$stmt->execute($data);

		$rec = $stmt->fetch(PDO::FETCH_ASSOC);
		$name = $rec['name'];
		$user_pass = $rec['user_pass'];
		$admission = $rec['admission'];
		$mail = $rec['mail'];

		$dbh=null;
	}
	catch(Exception $e)
	{
		print'ただいま障害により大変ご迷惑をお掛けしております。';
		exit();
	}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
	<title>利用者情報削除確認</title>
	<link rel="stylesheet" type="text/css" href="../common/common.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
		.margin{
			margin-left: 30px;
		}
		.form {
			width: 350px;
			background: #fdfdfd;
			opacity: 0.95;
			padding-left: 30px;
			padding-bottom: 10px;
			border-radius: 20px;
			box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
		}
	</style>
</head>

	<body class="all">
		<header>
			<p>利用者情報削除確認</p>
		</header>
		<div class="form-container">
			<div class="form">
				<label>
					<br />
					氏名<br />
					<?php print '「'.$name.'」'; ?>
					<br />
					ユーザー名<br />
					<?php print '「'.$user_name.'」'; ?>
					<br />
					入所月<br />
					<?php print '「'.$admission.'」'; ?>
					<br />
					メールアドレス<br />
					<?php print '「'.$mail.'」'; ?>
					<br />
					<br />
					上記のユーザーを削除します。<br />
					よろしいですか？<br />
					<br />
					<form method="post" action="delete_user_done.php">
						<input type="hidden"name="user_name" value="<?php print $user_name; ?>">
						<button type="button" onclick="history.back()">戻る</button>　　　　　　　　　　
						<button type="submit">ＯＫ</button>
						<!-- <input type="button" onclick="history.back()" value="戻る">
						<input type="submit" value="ＯＫ"> -->
					</form>
				</label>
			</div>
		</div>
	</body>
</html>