<?php
	//以下、連結時にコメントアウト解除

	session_start();
	session_regenerate_id(true);
	require_once('../common/common.php');
	login_check();
	// if(isset($_SESSION['user_login'])==false)
	// {
	// 	print 'ログインされていません。<br />';
	// 	print '<a href="../login/login.html">ログイン画面へ</a>';
	// 	exit();
	// }
	// else
	// {
	// 	print $_SESSION['user_name'];
	// 	print 'さんログイン中<br />';
	// 	print '<br />';
	// }

	try{
		require_once('../common/common.php');

		$post=sanitize($_POST);

		$user_name=$post['user_name'];				
		$edit_name=$post['edit_name'];
		$edit_user_name=$post['edit_user_name'];
		$edit_user_pass=$post['edit_user_pass'];
		$edit_admission=$post['edit_admission'];
		$edit_mail=$post['edit_mail'];				

		$dsn='mysql:dbname=bus;host=localhost;charset=utf8';
		$user='root';
		$password='';
		$dbh=new PDO($dsn,$user,$password);
		$dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

		$sql='UPDATE user_info SET user_name=?,user_pass=?,name=?,admission=?,mail=? WHERE user_name=?';
		$stmt=$dbh->prepare($sql);
		$data[]=$edit_user_name;
		$data[]=$edit_user_pass;
		$data[]=$edit_name;
		$data[]=$edit_admission;
		$data[]=$edit_mail;
		$data[]=$user_name;

		$stmt->execute($data);

		$dbh=null;
		$_SESSION['user_name']=$edit_user_name;

	}catch (Exception $e){
		print 'ただいま障害により大変ご迷惑をお掛けしております。';
		exit();
	}

?>

<!DOCTYPE html>
<html>
	<head>
        <meta charset="UTF-8">
        <title>ユーザ修正画面</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<style>
			.margin{
				margin-left: 30px;
			}
			.form {
				width: 360px;
				background: #fdfdfd;
				opacity: 0.95;
				padding-left: 10px;
				padding-bottom: 10px;
				border-radius: 20px;
				box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
				 text-align: center;
			}
		</style>
	</head>
	<body class="all">
		<header>
			<p>利用者情報修正完了</p>
		</header>
		<br><br>
		<div class="form-container">
			<div class="form">
				<label>
					修正しました。<br />
					<br />
					<button>
						<a href="../user_menu/user_reference.php">戻る</a>
					</button>
				</label>
			</div>
		</div>
	</body>
</html>