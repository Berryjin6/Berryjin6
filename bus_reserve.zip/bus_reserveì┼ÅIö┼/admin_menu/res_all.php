<?php
    session_start();
    session_regenerate_id(true);

    require_once('../common/common.php');

    $dsn = 'mysql:dbname=bus; host=localhost; charset=utf8';
    $user = 'root';
    $password = '';
    $dbh = new PDO($dsn, $user, $password);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    login_check_admin();

    echo '<h2>全予約状況</h2>';
    echo '<input type="button" onclick="history.back()" value="戻る"><br>';
    echo '<br>※座席イメージ';
    echo '<table id="bus_seat" border="1" style="background-color:white"></table>';
    echo '<hr>';

    user_reserve_all();

    $dbh = null;

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>全座席状況</title>
        <style>
            body{
                background-color: #dfffff;
            }
            #bus_seat{
                width: 300px;
                height: 200px;
                text-align: center;
            }
            #bus{
                width: 300px;
                height: 200px;
            }
            .bus{
                width: 50px;
                height: 40px;
                background-color: "black";
            }
            table[border="1"] .not{
                border: 1px solid white;
            }
            table .black{
                background-color: black;
            }
            #driver, #seat_1, #seat_2, #seat_3, #seat_4, .seat_num{
                width: 75px;
            }
            .week_seat{
                margin-right: 10px;
                float: left;
            }
            .float{
                text-align: center;
            }
            .logout{
                text-align:right;
            }
        </style>
    </head>
    <body>
        <script src="../common/jquery-3.4.1.min.js"></script>
        <script src="../common/common.js"></script>
        <script>
            'use strict'

            bus_table();
        </script>
    </body>
</html>
