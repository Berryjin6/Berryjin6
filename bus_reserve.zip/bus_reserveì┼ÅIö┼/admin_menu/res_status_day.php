<?php
    session_start();
    session_regenerate_id(true);
    // $_SESSION['admin_login'] = 1;
    // $_SESSION['admin_id'] = 1;
    // $_SESSION['admin_name'] = 'admin';
    // $_SESSION['user_login'] = 1;
    // $_SESSION['user_id'] = 1;
    // $_SESSION['user_name'] = 'username';

    require_once('../common/common.php');

    login_check_admin();

    try{
        $post = sanitize($_POST);
        $sel_year = $post['select_year'];
        $sel_month = $post['select_month'];
        $sel_day = $post['select_day'];

        $now_date = "{$sel_year}-{$sel_month}-{$sel_day}";
        $n_datetime = new DateTime($now_date);
        $nf_datetime = $n_datetime -> format("Y-m-d");

        if($now_date === $nf_datetime){
            $dsn = 'mysql:dbname=bus; host=localhost; charset=utf8';
            $user = 'root';
            $password = '';
            $dbh = new PDO($dsn, $user, $password);
            $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);



            $sel_year_month_day = $sel_year.'-'.$sel_month.'-'.$sel_day;
            $nowDateTime = new DateTime($sel_year_month_day);
            $w_d = $nowDateTime -> format("w");

            $d_o_w = week_day($w_d);

            echo '<h2>予約状況　指定日('.$sel_year.'年'.$sel_month.'月'.$sel_day.'日)'.$d_o_w.'曜日</h2>';
            echo '<input type="button" onclick="history.back()" value="戻る">';

            echo '<hr>';
            echo '<div>空き：<span style="border:solid 1px; background-color:white">　</span>　';
            echo '予約あり：<span style="background-color:black">　</span></div><br><br>';

            select_that_day();

            $dbh = null;
        }else{
            echo "{$sel_year}年{$sel_month}月に{$sel_day}日はありません。";
            echo '<br><input type="button" onclick="history.back()" value="戻る">';
            exit();
        }

    }catch(Exception $e){
        print 'ただいまご迷惑をお掛けしております。';
        print $e;
        exit();
    };

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>座席状況</title>
        <style>
            body{
                background-color: #dfffff;
            }
            #bus_seat{
                width: 300px;
                height: 200px;
            }
            #bus{
                width: 300px;
                height: 200px;
            }
            .bus{
                width: 50px;
                height: 40px;
                background-color: "black";
            }
            table[border="1"] .not{
                border: 1px solid white;
            }
            table .black{
                background-color: black;
            }
            #driver, #seat_1, #seat_2, #seat_3, #seat_4, .seat_num{
                width: 85px;
            }
            .week_seat{
                margin-right: 10px;
                float: left;
            }
            .seat_num{
                text-align: center;
            }
            .logout{
                text-align:right;
            }
        </style>
    </head>
    <body>
        <script src="../common/jquery-3.4.1.min.js"></script>
        <script src="../common/common.js"></script>
        
    </body>
</html>
