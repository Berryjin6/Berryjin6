<?php
    session_start(); 
    session_regenerate_id(true);
    //$_SESSION['admin_login']=1;//test用
    //$_SESSION['user_login']=0;//test用
    //$_POST['user_name']='Aさん';//test用
    //$user_name=$_POST['user_name'];
    @$admin_login=$_SESSION['admin_login'];
    @$user_login=$_SESSION['user_login'];
    


    ///////////////////////////////////////////////////////////////////////////////////////////
    //データベースへの接続
    ///////////////////////////////////////////////////////////////////////////////////////////
    $dsn='mysql:dbname=bus;host=localhost;charset=utf8';
    $user='root';
    $password='';
    //$dsn='mysql:dbname=bus;host=172.22.10.111;charset=utf8';
    //$user='bus_admin';
    //$password='pass';

    $dbh=new PDO($dsn,$user,$password);
    $dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);       

    ///////////////////////////////////////////////////////////////////////////////////////////
    //レコード読み出し
    //////////////////////////////////////////////////////////////////////////////////////////
    $sql="SELECT user_name FROM `user_info`";//user->user_info
    $stmt=$dbh->prepare($sql);
    $stmt->execute();
    $rec=$stmt->fetchall(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>利用者リスト</title>
    <link rel="stylesheet" type="text/css" href="../common/common.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .form {
                width: auto;
                background: #fdfdfd;
                opacity: 0.95;
                padding-left: 30px;
                padding-right: 30px;            
                padding-top: 30px;
                padding-bottom: 30px;
                border-radius: 20px;
                box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
            }
            a {
            width: auto;
            border-radius: 5px;
            color: black;
            }
            .center{
                text-align:center;
                color:black;
            }
            select[name="user_name"] option {
            color: black;
            }
        </style>
    </head>
    <body class="all">
        <header>
                <p>利用者リスト</p>
        </header>
        <br><br>
        <div class="form-container">
            <div class="form">
                <label>
                    <h2>
                        <div class="center">
                            利用者を選択
                        </div>
                    </h2>
                    <form method="post" action="?" >
    <!--ユーザの選択-->
<?php 
    //管理者の場合はプルダウン表示
    //ユーザの場合はログイン時にSESSION変数に入れているので選択しない
    if($admin_login==1){
        print'<select name="user_name" style="color: black; font-size: 20px; height: 35px;">';
        for($i=0;$i<count($rec);$i++){
            print('<option>'.$rec[$i].'</option>');
        }
        print'</select>';
    }
    elseif($user_login==1){
        print'<input type="hidden" name="user_name" value="'.$user_name.'">';
    }
?>
        <!--参照/予約確認のプルダウン-->
        <!--<select name='select_action'>
            <option>参照</option>
            <option>予約確認</option>
        </select>-->
        
        <!--submitボタン-->
                        <button type="submit"  formaction="../user_menu/user_reference.php">参照</button>
                        <button type="submit"  formaction="../reserve/res_status.php">予約確認</button>
                    </form>
                    <br>
                    <a href="../logout/admin_top.php">●管理者ページ</a><br><br>
                    <!-- <a href="../login/logout.php">●ログアウト</a><br><br> -->
                    <button type="button" onclick="history.back()">戻る</button>
                </label>
            </div>
        </div>
    </body>
</html>