<?php
 session_start(); 
 $user_name=$_POST['user_name'];
 $_SESSION['user_name']=$user_name;
 $select_action=$_POST['select_action'];

 if($select_action=='参照'){
    header('Location:user_reference.php');
 }
 else if($select_action=='予約確認'){
    header('Location:res_status.php');
 }




?>

