-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: bus
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(30) DEFAULT NULL,
  `admin_pass` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','1a1dc91c907325c69271ddf0c944bc72');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cancel`
--

DROP TABLE IF EXISTS `cancel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cancel` (
  `can_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `can_seat` varchar(15) DEFAULT NULL,
  `can_date` date NOT NULL,
  `can_time` time DEFAULT NULL,
  `comp` int(11) DEFAULT 0,
  PRIMARY KEY (`can_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cancel`
--

LOCK TABLES `cancel` WRITE;
/*!40000 ALTER TABLE `cancel` DISABLE KEYS */;
INSERT INTO `cancel` VALUES (1,10,NULL,'2023-06-29','07:50:00',1),(2,40,NULL,'2023-06-30','07:50:00',0),(3,44,NULL,'2023-06-30','07:50:00',0);
/*!40000 ALTER TABLE `cancel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(15) DEFAULT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `text` varchar(600) DEFAULT NULL,
  `class` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (1,'にんじん','2023-06-28 01:00:27','aaaaa','要望',0),(2,'にんじん','2023-06-28 03:34:31','fefwef','運転について',0),(4,'aa','2023-06-28 03:34:59','fwefwf','その他',0),(5,'むらかみ','2023-06-29 02:15:21','運転荒いよ','運転について',0),(6,'john','2023-06-29 02:50:03','バスの本数を増やして','運転について',0),(7,'ポリ・テク男','2023-06-29 02:57:43','aaa','要望',0),(8,'1234','2023-06-29 03:53:24','大きい','運転について',0),(9,'7895','2023-06-29 04:57:37','遅い','その他',0);
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reserve`
--

DROP TABLE IF EXISTS `reserve`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reserve` (
  `res_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `res_seat` varchar(15) DEFAULT NULL,
  `res_date` date NOT NULL,
  `res_time` time DEFAULT NULL,
  `res_yn` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`res_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reserve`
--

LOCK TABLES `reserve` WRITE;
/*!40000 ALTER TABLE `reserve` DISABLE KEYS */;
INSERT INTO `reserve` VALUES (1,1,'1','2023-01-01','07:50:00','yes'),(2,1,'1','2023-01-02','07:50:00','yes'),(5,1,'1','2023-06-29','07:50:00','yes'),(7,11,'3','2023-06-29','07:50:00','yes'),(8,17,'6','2023-06-29','07:50:00','yes'),(10,16,'5','2023-06-29','07:50:00','yes'),(11,15,'4','2023-06-29','07:50:00','yes'),(12,14,'2','2023-06-29','07:50:00','yes'),(13,13,'8','2023-06-29','07:50:00','yes'),(14,12,'9','2023-06-29','07:50:00','yes'),(15,10,'3','2023-06-30','07:50:00','yes'),(17,10,'7','2023-06-29','07:50:00','yes'),(18,18,'7','2023-06-29','08:00:00','yes'),(20,14,'3','2023-07-29','07:50:00','yes'),(21,12,'1','2023-07-29','07:50:00','yes'),(22,13,'2','2023-07-29','07:50:00','yes'),(23,1,'8','2023-07-29','07:50:00','yes'),(24,18,'7','2023-07-29','07:50:00','yes'),(25,15,'4','2023-07-29','07:50:00','yes'),(26,16,'5','2023-07-29','07:50:00','yes'),(27,23,'3','2023-07-01','08:10:00','yes'),(28,23,'6','2023-06-30','08:30:00','yes'),(29,23,'1','2023-07-02','08:50:00','yes'),(30,24,'6','2023-06-30','08:10:00','yes'),(31,24,'5','0000-00-00','08:40:00','yes'),(32,24,'6','2023-07-02','08:00:00','yes'),(33,17,'6','2023-07-29','07:50:00','yes'),(34,23,'9','2023-07-29','07:50:00','yes'),(35,19,'4','0000-00-00','08:40:00','yes'),(36,28,'1','2023-06-30','07:50:00','yes'),(37,29,'2','2023-06-30','07:50:00','yes'),(38,31,'5','2023-06-30','07:50:00','yes'),(39,32,'6','2023-06-30','07:50:00','yes'),(41,34,'8','2023-06-30','07:50:00','yes'),(42,36,'4','2023-06-30','07:50:00','yes'),(43,39,'9','2023-06-30','07:50:00','yes'),(45,24,'1','2024-01-01','07:50:00','yes'),(47,24,'2','2023-07-28','07:50:00','yes'),(49,32,'1','2023-08-14','07:50:00','yes');
/*!40000 ALTER TABLE `reserve` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_info` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(30) DEFAULT NULL,
  `user_pass` varchar(32) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `admission` varchar(50) DEFAULT NULL,
  `mail` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_info`
--

LOCK TABLES `user_info` WRITE;
/*!40000 ALTER TABLE `user_info` DISABLE KEYS */;
INSERT INTO `user_info` VALUES (1,'にんじん','1a1dc91c907325c69271ddf0c944bc72','間中','4','XXXX@XXXX.com'),(10,'aa','0cc175b9c0f1b6a831c399e269772661','aaa','2023-01','AAAA@AAAA.com'),(11,'er4','0cc175b9c0f1b6a831c399e269772661','aaaaaa','2023-08','AAAA@BBBB.com'),(12,'1','c4ca4238a0b923820dcc509a6f75849b','11','2023-03','AAAA@AAAA.com'),(13,'2','c81e728d9d4c2f636f067f89cc14862c','22','2023-08','XXXX@XXXX.com'),(14,'3','eccbc87e4b5ce2fe28308fd9f2a7baf3','3','2023-08','XXXX@XXXX.com'),(15,'4','a87ff679a2f3e71d9181a67b7542122c','44','2023-02','AAAA@AAAA.com'),(16,'5','e4da3b7fbbce2345d7772b0674a318d5','55','2023-07','AAAA@BBBB.com'),(17,'6','1679091c5a880faf6fb5e6087eb1b2dc','66','2023-07','AAAA@AAAA.com'),(18,'7','8f14e45fceea167a5a36dedd4bea2543','77','2023-08','XXXX@XXXX.com'),(19,'むらかみ','0cc175b9c0f1b6a831c399e269772661','むらかみ','2023-04','murakami@gmail.co'),(20,'32','0cc175b9c0f1b6a831c399e269772661','aaa','2023-03','XXXX@XXXX.com'),(21,'44','f7177163c833dff4b38fc8d2872f1ec6','4444','2023-12','AAAA@BBBB.com'),(22,'aaa','0cc175b9c0f1b6a831c399e269772661','aaaa','2023-03','AAAA@AAAA.com'),(23,'たろ','3886bc9c9655241c5737d45eec5447bb','taro','2023-07','murakami@gmail.com'),(24,'ポリ・テク男','e0e5706bcb59ed07a83c87b354828c5f','ポリテク男','2023-07','murakami@gmail.com'),(25,'田中','245f5f86628abb7b2e0ae9ac72b8e888','たなか','2023-08','murakami@gmail.com'),(26,'茨城太郎','8ec25dbcefad23ec2dcb3bd816bbe786','いばらき','2023-06','ibaraki@gmail.com'),(27,'いばらまん','2c90c187a5ebc89cc2d90b05315b7f97','いばいば','2023-03','1@gmail.com'),(28,'ユーザA','ee11cbb19052e40b07aac0ca060c23ee','user','2023-07','murakami@gmail.com'),(29,'ユーザB','ee11cbb19052e40b07aac0ca060c23ee','user','2023-07','a@gmail.com'),(30,'たけし','3a7f033fbaa3d7351bc591dd677f3312','たけし','2023-07','ibaraki@gmail.com'),(31,'おさむらい','8d19b047942fc8c553a32a94e3e388f0','おさむらい','2023-02','a@gmail.com'),(32,'消しカス食べ男a','0cc175b9c0f1b6a831c399e269772661','けしかすa','2023-02','aa@gmail.com'),(34,'ポリ・テック','e0e5706bcb59ed07a83c87b354828c5f','ぽ','2023-07','a@gmail.com'),(35,'ユーザ','ee11cbb19052e40b07aac0ca060c23ee','admin','2023-07','1@gmail.com'),(36,'農家','064171c058afee549347949666754b8c','のうか','2023-06','1@gmail.com'),(37,'33333','eccbc87e4b5ce2fe28308fd9f2a7baf3','かぼちゃ','2023-03','XXXX@XXXX.com'),(38,'ポリ子','3ff40f8cc0b463c7510a5e09e5a5e678','ぽりこ','2023-02','pori@yahoo.co.jp'),(39,'user','ee11cbb19052e40b07aac0ca060c23ee','user','2023-02','user@mail.com'),(42,'1234','c4ca4238a0b923820dcc509a6f75849b','にんじん','2023-02','XXXX@XXXX.com'),(44,'7894','c4ca4238a0b923820dcc509a6f75849b','にんじん','2023-04','XXX@XXX.com');
/*!40000 ALTER TABLE `user_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-29 14:46:11
