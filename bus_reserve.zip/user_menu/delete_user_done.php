<?php
	session_start();
	session_regenerate_id(true);
	require_once('../common/common.php');
	login_check();

	try{
		$post=sanitize($_POST);

		$user_name=$post['user_name'];

		$dsn='mysql:dbname=bus;host=localhost;charset=utf8';
		$user='root';
		$password='';
		$dbh=new PDO($dsn,$user,$password);
		$dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

		$sql='SELECT user_id FROM user_info WHERE user_name=?';
		$stmt=$dbh->prepare($sql);
		$data = [];
		$data[]=$user_name;
		$stmt->execute($data);

		$rec = $stmt -> fetch(PDO::FETCH_ASSOC);
		$user_id = $rec['user_id'];

		$sql='DELETE FROM reserve WHERE user_id=?';
		$stmt=$dbh->prepare($sql);
		$data = [];
		$data[]=$user_id;
		$stmt->execute($data);

		$sql='DELETE FROM user_info WHERE user_id=?';
		$stmt=$dbh->prepare($sql);
		$data = [];
		$data[]=$user_id;
		$stmt->execute($data);

		$dbh=null;

	}
	catch (Exception $e){
		print 'ただいま障害により大変ご迷惑をお掛けしております。';
		exit();
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>利用者情報削除完了</title>
		<link rel="stylesheet" type="text/css" href="../common/common.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<style>
			.margin{
				margin-left: 30px;
			}
			.form {
				width: 350px;
				background: #fdfdfd;
				opacity: 0.95;
				padding-left: 10px;
				padding-bottom: 10px;
				border-radius: 20px;
				box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
				text-align:center;
			}
		</style>
	</head>
	<body class="all">
		<header>
			<p>利用者情報削除完了</p>
		</header>
		<div class="form-container">
			<div class="form">
				<label>
					利用者情報の削除が完了しました。<br />
					<br />
					<button>
						<a href="../admin_menu/user_list.php"> 戻る</a>
					</button>
				</label>
			</div>
		</div>
	</body>
</html>