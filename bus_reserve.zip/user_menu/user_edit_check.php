<?php
	//以下、連結時にコメントアウト解除

	session_start();
	session_regenerate_id(true);
	require_once('../common/common.php');
	login_check();
	// if(isset($_SESSION['user_login'])==false)
	// {
	// 	print 'ログインされていません。<br />';
	// 	print '<a href="../login/login.html">ログイン画面へ</a>';
	// 	exit();
	// }
	// else
	// {
	// 	print $_SESSION['user_name'];
	// 	print 'さんログイン中<br />';
	// 	print '<br />';
	// }
	try{
		require_once('../common/common.php');

		$post=sanitize($_POST);

		$edit_name=$post['edit_name'];
		$edit_user_name=$post['edit_user_name'];
		$edit_user_pass=$post['edit_user_pass'];
		$edit_user_pass2=$post['edit_user_pass2'];
		$edit_admission=$post['edit_admission'];
		$edit_mail=$post['edit_mail'];
		$user_name=$_SESSION['user_name'];

		// データベースから同じユーザーネームがあるか検索
		$dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
		$user = 'root';
		$password = '';
		$dbh = new PDO($dsn,$user,$password);
		$dbh -> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

		$sql = 'SELECT user_id FROM user_info WHERE user_name=?';
		$stmt = $dbh->prepare($sql);
		$data[] = $edit_user_name;
		$stmt -> execute($data);

		$rec = $stmt -> fetch(PDO::FETCH_ASSOC);
	}catch(Exception $e){
		print 'ただいまご迷惑をお掛けしております。';
		print $e;
		exit();
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>利用者情報修正</title>
		<link rel="stylesheet" type="text/css" href="../common/common.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<style>
			.margin{
				margin-left: 30px;
			}
			.form {
				width: 390px;
				background: #fdfdfd;
				opacity: 0.95;
				padding-left: 30px;
				padding-bottom: 10px;
				border-radius: 20px;
				box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
			}
		</style>
	</head>
	<body class="all">
		<header>
			<p>利用者情報修正</p>
		</header>
		<div class="form-container">
			<div class="form">
				<label>
<?php
	print '<br>';

	if($edit_name==''){
		print '・利用者名が入力されていません。<br />';
	}else{
		print '・利用者名：';
		print $edit_name;
		print '<br />';
	}

	if($edit_user_name ==''){
		print 'ユーザー名が入力されていません。<br>';
	}elseif($rec !== false){
		if($rec['user_id'] != $_SESSION['user_id'] ){
			print $edit_user_name.'は登録済みのユーザー名です。<br>';		
		}
	}else{
		print 'ユーザー名:';
		print $edit_user_name;
		print '<br>';
	}

	if($edit_user_pass==''){
		print '・パスワードが入力されていません。<br />';
	}

	if($edit_user_pass!=$edit_user_pass2){
		print '・パスワードが一致しません。<br />';
	}

	if($edit_admission==''){
		print '・入所月が入力されていません。<br />';
	}else{
		print '・入所月：';
		print $edit_admission;
		print '<br />';
	}

	if($edit_mail==''){
		print '・メールアドレスが入力されていません。<br />';
		print '<br />';
	}else if(preg_match('/\A[\w\-\.]+\@[\w\-\.]+\.([a-z]+)\z/', $edit_mail)==0){
		print 'メールアドレスを正確に入力してください。';
	}else{
		print '・メールアドレス：';
		print $edit_mail;
		print '<br />';
	}

	if($edit_name=='' || $edit_user_pass=='' || $edit_user_pass!=$edit_user_pass2){
		print '<form>';
		print '<input type="button" onclick="history.back()" value="戻る">';
		print '</form>';
	}else{
		$edit_user_pass=md5($edit_user_pass);
		$edit_user_pass2=md5($edit_user_pass2);

		print '<form method="post" action="user_edit_done.php">';
		print '<input type="hidden" name="user_name" value="'.$user_name.'">';
		print '<input type="hidden" name="edit_name" value="'.$edit_name.'">';
		print '<input type="hidden" name="edit_user_name" value="'.$edit_user_name.'">';
		print '<input type="hidden" name="edit_user_pass" value="'.$edit_user_pass.'">';
		print '<input type="hidden" name="edit_user_pass2" value="'.$edit_user_pass2.'">';
		print '<input type="hidden" name="edit_admission" value="'.$edit_admission.'">';
		print '<input type="hidden" name="edit_mail" value="'.$edit_mail.'">';
		print '<br />';
		print '<button type="button" onclick="history.back()">戻る</button>　　　　　　　　　　';
		print '<button type="submit">ＯＫ</button>';
		// print '<input type="button" onclick="history.back()" value="戻る">';
		// print '<input type="submit" value="ＯＫ">';
		print '</form>';
	}
?>
				</label>
			</div>
		</div>
	</body>
</html>