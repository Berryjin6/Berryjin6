<?php
    session_start(); 
    // @$admin_login=$_SESSION['admin_login'];
    // @$user_login=$_SESSION['user_login'];
    if(isset($_POST['user_name'])==false){
        $select_user_name=$_SESSION['user_name'];
    }else{
        $select_user_name=$_POST['user_name'];
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////
    //データベースへの接続
    ///////////////////////////////////////////////////////////////////////////////////////////
    $dsn='mysql:dbname=bus;host=localhost;charset=utf8';
    $user='root';
    $password='';
        //$dsn='mysql:dbname=bus;host=172.22.10.111;charset=utf8';
        //$user='bus_admin';
        //$password='pass';

    $dbh=new PDO($dsn,$user,$password);
    $dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);       

    ///////////////////////////////////////////////////////////////////////////////////////////
    //レコード読み出し
    //////////////////////////////////////////////////////////////////////////////////////////
    $sql="SELECT * FROM `user_info` WHERE user_name=?";//user_info
    $data[]=$select_user_name;
    $stmt=$dbh->prepare($sql);
    $stmt->execute($data);
    $rec=$stmt->fetch(PDO::FETCH_ASSOC);

    $user_id=$rec['user_id'];
    $user_name=$rec['user_name'];
    $name=$rec['name'];
    $admission=$rec['admission'];
    $mail=$rec['mail'];
    $_SESSION['user_login'] = 1;
    $_SESSION['user_name']=$user_name;
    $_SESSION['user_id']=$user_id;

    $back = '<a href="../reserve/res_status.php">座席状況へ</a>';
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>利用者情報参照</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<style>
			.margin{
				text-align:center;
			}
			.form {
				width: auto;
				background: #fdfdfd;
				opacity: 0.95;
				padding-left: 30px;
                padding-right: 30px;
				padding-bottom: 10px;
				border-radius: 20px;
				box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
			}
            * {
                font-family: serif;
                color: black;
                box-sizing: border-box;
            
            }
            .center{
                text-align:center;
            }
		</style>
    </head>
    <body class="all">
        <header> 
            <p>利用者情報参照</p> 
        </header>
		<br><br>
		<div class="form-container">
			<div class="form">
				<label>
                    <br>
                    <table border="1">
                        <tr><th>ID</th><th>ユーザネーム</th><th>氏名</th><th>入所月</th><th>メールアドレス</th></tr>
                        <?php print'<tr><td>'.$user_id.'</td><td>'.$user_name.'</td><td>'.$name.'</td><td>'.$admission.'</td><td>'.$mail.'</td></tr>' ?>
                    </table>
                    <form method="post" action="?" >
                        <input type="hidden" name=user_name value=<?php print $select_user_name ?>>
                        <br>
                        <div class="margin">
                            <button type="submit" formaction="../reserve/res_status.php">予約確認</button> 
                            <button type="submit" formaction="user_edit.php">修正</button> 
                        </div>
<?php
    if(isset($_SESSION['admin_login'])){ 
        print'<button type="submit" formaction="delete_user.php">削除</button>';
    }
?>
                    </form>
<?php 
    // echo $back;
?>
                </label>
			</div>
		</div>
    </body>
</html>