<?php

//以下、連結時にコメントアウト解除

	session_start();
	session_regenerate_id(true);
	require_once('../common/common.php');
	login_check();
// if(isset($_SESSION['user_login'])==false)
// {
// 	print 'ログインされていません。<br />';
// 	print '<a href="../login/login.html">ログイン画面へ</a>';
// 	exit();
// }
// else
// {
// 	print $_SESSION['user_name'];
// 	print 'さんログイン中<br />';
// 	print '<br />';
// }

	try {
		$user_name=$_SESSION['user_name'];

		$dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
		$user = 'root';
		$password = '';
		$dbh = new PDO($dsn, $user, $password);
		$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		$sql = 'SELECT name, user_pass, admission, mail FROM user_info WHERE user_name = ?';
		$stmt = $dbh->prepare($sql);
		$data[] = $user_name;
		$stmt->execute($data);

		$rec = $stmt -> fetch(PDO::FETCH_ASSOC);

		$dbh=null;
		}
		catch (Exception $e)
		{
			print 'ただいま障害により大変ご迷惑をお掛けしております。';
			exit();
	}
?>

<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8"><!--要素一：文字コード-->
        <title>ユーザ修正画面</title><!--要素二：ページのタイトルを指定-->
        <!-- <link rel="stylesheet" type="text/css" href="../common/common.css">2.要素三：CSSの読み込み -->
        <link rel="stylesheet" type="text/css" href="../common/common.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<style>
			.margin{
				margin-left: 30px;
			}
			form {
				width: 400px;
				background: #fdfdfd;
				opacity: 0.95;
				padding-left: 30px;
				padding-bottom: 10px;
				border-radius: 20px;
				box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
			}
		</style>
		
</head>
<body class="all">

        <header>
        
            <!--  <i class="fa fa-bus" style="font-size:80px;color:rgb(6, 5, 18)"></i>    -->
            <p>ユーザ修正画面</p> 


        </header>

	

	<!-- <a href="user_logout.php">ログアウト</a><br> -->

	<!-- 利用者情報修正<br /> -->
	<div class="form-container">
		<form method="post" action="user_edit_check.php">
		
		<input type="hidden" name="user_name" value="<?php print $user_name; ?>">
		<div class="margin">
		<br>
		<label>氏名</label><br>
		<input class="text-box" type="text" name="edit_name" style="width:200px" value="<?php print $rec['name']; ?>"><br />
		<label>ユーザー名</label><br />
		<input type="text" name="edit_user_name" style="width:200px" value="<?php print $user_name; ?>"><br />
		<label>パスワードを入力してください。</label><br />
		<input type="password" name="edit_user_pass" style="width:100px"><br />
		<label>パスワードをもう1度入力してください。</label><br />
		<input type="password" name="edit_user_pass2" style="width:100px"><br />
		<label>入所月</label><br />
		<input type="month" step='1' name="edit_admission" style="width:200px" value="<?php print $rec['admission']; ?>"><br />
		<label>メールアドレス</label><br />
		<input type="email" name="edit_mail" style="width:200px" value="<?php print $rec['mail']; ?>"><br />
		<br>

		<button type="button" onclick="history.back()">戻る</button>　　　　　　　　　　　　　　　　　
		<button type="submit">ＯＫ</button>
		</div>

		</form>
	</div>

</body>
</html>