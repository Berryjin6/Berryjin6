<?php
    session_start();
    session_regenerate_id(true);
    // $_SESSION['admin_login'] = 1;
    // $_SESSION['admin_id'] = 1;
    // $_SESSION['admin_name'] = 'admin';
    // $_SESSION['user_login'] = 1;
    // $_SESSION['user_id'] = 1;
    // $_SESSION['user_name'] = 'username';

    require_once('../common/common.php');

    $dsn = 'mysql:dbname=bus; host=localhost; charset=utf8';
    $user = 'root';
    $password = '';
    $dbh = new PDO($dsn, $user, $password);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    login_check_admin();

    echo '<h2>予約状況指定</h2>';

    echo '<form method="post" action="res_status_day.php">';
        select_year();
        select_month();
        select_day();
        print'　　<input type="submit" value="送信">';
    echo '</form>';

    print '<a href="res_all.php">全予約確認</a><br/>';


    $nowDateTime = new DateTime();

    if($nowDateTime -> format('H') <= 12){
        $nowDateTime -> modify('-1 days');
    }
    $nowDateTime -> modify('+1 days');
    $sel_year = $nowDateTime -> format('Y');
    $sel_month = $nowDateTime -> format('m');
    $sel_day = $nowDateTime -> format('d');

    $nowDateTime -> modify('+6 days');

    $sel2_year = $nowDateTime -> format('Y');
    $sel2_month = $nowDateTime -> format('m');
    $sel2_day = $nowDateTime -> format('d');

    echo '<hr>';
    echo '<h2>座席予約状況（'.$sel_year.'年'.$sel_month.'月'.$sel_day.'日～'.$sel2_year.'年'.$sel2_month.'月'.$sel2_day.'日）</h2>';
    echo '<div>空き：<span style="border:solid 1px; background-color:white">　</span>　';
    echo '予約あり：<span style="background-color:black">　</span></div><br><br>';

    that_dayAll();

    $dbh = null;
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>座席状況(全)</title>
        <style>
            body{
                background-color: #dfffff;
            }
            #bus_seat{
                width: 300px;
                height: 200px;
            }
            #bus{
                width: 300px;
                height: 200px;
            }
            .bus{
                width: 50px;
                height: 40px;
                background-color: "black";
            }
            table[border="1"] .not{
                border: 1px solid white;
            }
            table .black, table .black_week{
                background-color: black;
            }
            #driver, #seat_1, #seat_2, #seat_3, #seat_4, .seat_num{
                width: 75px;
            }
            .week_seat{
                margin-right: 10px;
                float: left;
            }
            .seat_num{
                text-align: center;
            }
            .logout{
                text-align:right;
            }
        </style>
    </head>
    <body>
        <script src="../common/jquery-3.4.1.min.js"></script>
        <script src="../common/common.js"></script>
    </body>
</html>
