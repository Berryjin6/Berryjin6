<?php

    session_start();
    session_regenerate_id(true);
    require_once('../common/common.php');
    login_check_admin();

        try{
            require_once('../common/common.php');
            $message='';
            $today=new DateTime('now');
                   

            if(@$_POST['start_date']==true){
                $start_date=$_POST['start_date'];//集計開始日
                $start_value=$_POST['start_date'];//フォーム内の集計開始日のデフォルト値
            }
            else{
                //$start_date=date('Y-m-d');
                $start_date=$today->format('Y-m-d');
                $start_value=$start_date;
            }
            
            if(@$_POST['end_date']==true){
                $end_date=$_POST['end_date'];//集計終了日
                $end_value=$_POST['end_date'];//フォーム内の集計終了日のデフォルト値
            }
            else{
                //$end_date=date('Y-m-d');
                $nextweek=$today->modify('+1 month');
                $end_date=$nextweek->format('Y-m-d');
                $end_value=$end_date;
            }

            if($start_date>$end_date){//集計開始日<集計終了日の時　メッセージ表示＋今日の日付でグラフ表示
                $message='<p>集計開始日< 集計終了日になっています!</p></br>';
                $show_flag=0;
            }


            $start_date= '"'.$start_date.'"';
            $end_date= '"'.$end_date.'"';

            ///////////////////////////////////////////////////////////////////////////////////////////
            //データベースへの接続
            ///////////////////////////////////////////////////////////////////////////////////////////
            $dsn='mysql:dbname=bus;host=localhost;charset=utf8';
            $user='root';
            $password='';
            $dbh=new PDO($dsn,$user,$password);
            $dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);            
                    
            ///////////////////////////////////////////////////////////////////////////////////////////
            //予約のレコード読み出し(保留) 
            //////////////////////////////////////////////////////////////////////////////////////////
            $sql="SELECT res_time,count(res_time) FROM `reserve` WHERE res_date BETWEEN ".$start_date." AND ".$end_date."GROUP BY res_time"; /*時間ごとにgroup化し　ある期間での各々の予約待ちの合計を求める*/
            $stmt=$dbh->prepare($sql);
            $stmt->execute();
            /*日付のデータを切り出して検索できるような状態にどうにかする処理をここに加える？？*/
            while(true){
                $rec=$stmt->fetch(PDO::FETCH_ASSOC);
                if($rec==false){
                    break;
                }
                $res_label[]=substr($rec['res_time'],0,5);
                $res_count[]=(int)$rec['count(res_time)'];
            }
            $rec=array();

            ///////////////////////////////////////////////////////////////////////////////////////////
            //キャンセル待ちのレコード読み出し
            //////////////////////////////////////////////////////////////////////////////////////////
            $sql="SELECT can_time,count(can_time) FROM `cancel` WHERE can_date BETWEEN ".$start_date." AND ".$end_date."GROUP BY can_time"; /*時間ごとにgroup化し　ある期間での各々の予約待ちの合計を求める*/
            $stmt=$dbh->prepare($sql);
            $stmt->execute();
            /*日付のデータを切り出して検索できるような状態にどうにかする処理をここに加える？？*/
            while(true){
                $rec=$stmt->fetch(PDO::FETCH_ASSOC);
                if($rec==false){
                    break;
                }
                $can_count[]=(int)$rec['count(can_time)'];
            }
            $rec=array();

            if(empty($res_label)==1){//ラベルデータがないとき　
                $show_flag=0;//非表示
                if($message==false){
                    $message='<p>該当データがありません</p></br>';
                }
            }
            else{//データがある時
                $show_flag=1;//グラフ表示
                $js_res_label=json_encode($res_label);
                $js_res_count=json_encode($res_count);
                $js_can_count=json_encode($can_count);
                $js_show_flag=json_encode($show_flag);
            }
            

            //$js_res_count=json_encode($res_count);


            $dbh=null;
        }

        catch(Exception $e){
            print'エラー';
            exit();
        }
        ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>キャンセル待ちデータグラフ
        </title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .form {
                width: auto;
                background: #fdfdfd;
                opacity: 0.95;
                padding-left: 30px;
                padding-right: 30px;
                padding-bottom: 10px;
                border-radius: 20px;
                box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
            }
            input{
                width: auto;
                display:inline-block
            }
        </style>
    </head>
    <body class="all">
    <header>
        <!-- <h1 id="title">お問い合わせ</h1> -->
        <p>キャンセル待ちデータグラフ</p>
        </header>
        <br />
        <br />
        <div class="form-container">
            <div class="form">
                <label>
                    <!-- <a href="../admin_menu/admin_top.php">管理者ページ</a><br>
                       <a href="../login/logout.php">ログアウト</a><br><br> -->


        <?php print $message; ?>
        <div style="width: 500px;" ><canvas id="canvas" ></canvas></div>

        集計期間
        <form action="can_res_view.php" method="post">
            <input type="date" name="start_date" value="<?php print$start_value?>">～
            <input type="date" name="end_date" value="<?php print$end_value?>">
            <input type="submit" value="実行"><br><br>
            <button>
            <a href="../logout/admin_top.php">戻る</a>
            </button>
        </form>


        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.3.2/chart.min.js"></script>
        <script>
                let canvas=document.getElementById("canvas");
                let res_label=<?php echo $js_res_label?>;
                let res_count=<?php echo $js_res_count?>;
                let can_count=<?php echo $js_can_count?>;
                let show_flag=<?php echo $js_show_flag?>;
                

                if(show_flag==1){
                    let myLineChart=new Chart(canvas,{
                        type:'bar',
                        data:{
                            labels:res_label,
                            datasets:[
                                {
                                    label:'予約数',
                                    data:res_count,
                                    backgroundColor:"rgba(219,39,91,0.5)"
                                },
                                {
                                    label:'キャンセル待ち数',
                                    data:can_count,
                                    backgroundColor:"rgba(111,139,91,0.5)"
                                }
                            ],
                        },
                        options:{
                            plugins:{
                                title:{
                                    display:true,
                                    text:'キャンセル待ち数，予約数'
                                }
                            },

                            scales:{
                                yAxes:{
                                    ticks:{
                                        suggestedmax:70,
                                        suggestedMin:0,
                                        stepSize:10,
                                        callback:function(value,index,values){
                                            return value
                                        }
                                    }
                                }
                            },
                        }
                    });
                }
            </script>
                </label>
            </div>
        </div>
    </body>
</html>