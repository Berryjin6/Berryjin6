<?php
    //ローカル環境でのテストではログインチェックのセッションをコメントアウト
    session_start();
    session_regenerate_id(true);
    require_once('../common/common.php'); 
    login_check_admin();

    // // ローカル環境でのテストではセッションに仮の値を代入
    // $admin_name = 'kanrisha';
    $admin_name = $_SESSION['admin_name'];

    try{
        // データベースに接続する
        $dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
        $user = 'root';
        $password = '';
        $dbh = new PDO($dsn,$user,$password);
        $dbh -> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

        $max = 0;

        // SQL文で指令を出す
        // 問い合わせ一覧に表示するカラムの値を取り出す
            $sql = 'SELECT id, c.user_name, mail, datetime, class, text, status FROM contact AS c LEFT OUTER JOIN user_info AS u ON c.user_name = u.user_name ORDER BY datetime';
            $stmt = $dbh->prepare($sql);
            $stmt -> execute();

            while(true){
                // 参照結果から1件分のデータを取り出す
                $rec = $stmt -> fetch(PDO::FETCH_ASSOC);
                if(!$rec){
                    break;
                }

                // 問い合わせた結果を配列に追加
                $id[] = $rec['id'];
                $user_name[] = $rec['user_name'];
                $mail[] = $rec['mail'];
                $datetime[] = $rec['datetime'];
                $class[] = $rec['class'];
                $text[] = $rec['text'];
                switch($rec['status']){
                    case 0:
                        $rec_status = '未対応';
                        break;

                    case 1:
                        $rec_status = '対応中';
                        break;

                    case 2:
                        $rec_status = '対応済み';
                        break;

                    default:
                        break;
                }
                $status[] = $rec_status;
                $max++;
           }
        
        // データベースを切断する
        $dbh = null;                

    }catch(Exception $e){
        print 'ただいまご迷惑をお掛けしております。';
        print $e;
        exit();
    }
?>

<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
        <title>問い合わせデータ表示画面</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
    	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .form {
                width: auto;
                background: #fdfdfd;
                opacity: 0.95;
                padding-left: 30px;
                padding-right: 30px;            
                padding-top: 20px;
                padding-bottom: 20px;
                border-radius: 20px;
                box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
            }
            label {
                color:black;
            }
            table {
              color: black;
            }
            table td, table th {
                color: black;
            }
            h1{
                text-align: center;
            }
            .links{
                text-align: right;
            }
        </style>
    </head>
    <body class="all">
    <header>
            <p>お問い合わせ一覧</p>
    </header>
    <br><br>
        <!-- <?php print $admin_name; ?> -->
        <!-- <?php print $admin_name; ?> -->

        <div class="form-container">
			<div class="form">
				<label>
                    <table border = "1">
                        <tr>
                            <th>ID</th>
                            <th>利用者名</th>
                            <th>メールアドレス</th>
                            <th>問い合わせ日時</th>
                            <th>カテゴリ</th>
                            <th>問い合わせ内容</th>
                            <th>状況</th>
                        </tr>
<?php for($i = 0; $i < $max; $i++){
    echo '<tr>
        <td>'.$id[$i].'</td>
        <td>'.$user_name[$i].'</td>
        <td>'.$mail[$i].'</td>
        <td>'.$datetime[$i].'</td>
        <td>'.$class[$i].'</td>
        <td id="con_txt">'.$text[$i].'</td>
        <td>'.$status[$i].'</td>
    </tr>';
}
?>
                    </table>
                    <br/>
                    <button>
                        <a href="../logout/admin_top.php">戻る</a>
                    </button>
                </label>
            </div>
		</div>
    </body>
</html>