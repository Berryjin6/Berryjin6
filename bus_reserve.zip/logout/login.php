<?php
session_start();
$_SESSION=array();
if(isset($_COOKIE[session_name()])==true)
{
    setcookie(session_name(),'',time()-42000,'/');
}
session_destroy();
?>
<!DOCTYPE html><!--DOCTYPE宣言：HTMLのバージョンを指定-->
<html>

    <head><!--WEBページの設定を書く、三つの要素-->
        <meta charset="UTF-8"><!--要素一：文字コード-->
        <title>送迎バス予約システム</title><!--要素二：ページのタイトルを指定-->
        <link rel="stylesheet" type="text/css" href="../common/login.css"><!--2.要素三：CSSの読み込み-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>

    <body><!--実際に表示したい内容、ブラウザに表示されるのは<body>の内容のみ-->
       
        <header>
            <h1>送迎バス<br>
            予<span>       約     </span></h1>
        </header>
     
        <form method="post" action="../login/login_check.php"><!--7.-->

            <h2>ログイン</h2><!--1.ログイン区域の文字-->
            <label><i class="fa fa-user" style="font-size:20px"></i> ユーザー名</label> 
            <!--3.文字-->
            <input class="text-box" type="text" name="name" placeholder="Username"><br /><!--4.nameボックス内で自動で表示文字、ボックスの長さを指定-->           
             <!--5.-->  
             
             <label><i class="fa fa-shield" style="font-size:20px"></i> パスワード</label> 
             <input class="text-box" type="password" name="pass" placeholder="Password"><br /><!--6.passボックス内で自動で表示文字、ボックスの長さを指定-->

            <input class="button" type="submit" value="ログイン">         
           
            <a class="link" href="../login/signup.html">ご登録はこちら</a>

        </form>

    </body>

</html>