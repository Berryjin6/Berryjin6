<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>利用者登録確認</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
    	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
		.margin{
			margin-left: 140px;
		}
		.form {
			width: 390px;
			background: #fdfdfd;
			opacity: 0.95;
			padding-left: 30px;
			padding-bottom: 10px;
			border-radius: 20px;
			box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
		}
	</style>
    </head>
    <body class="all">
        <header>
            <p>利用者登録確認</p>
        </header>
        <br><br>
        <div class="form-container">
			<div class="form">
				<label>
        <?php

        require_once('../common/common.php');

        $post = sanitize($_POST);
        $add_user_name = $post['user_name'];
        $add_user_pass = $post['pass'];
        $add_user_pass2 = $post['pass2'];
        $add_name = $post['name'];
        $add_admission = $post['admission'];
        $add_mail = $post['mail'];

        if($add_user_name =='')
        {
            print '<br>';
            print '・ユーザー名が入力されていません。<br>';
        }
        else
        {
            print '<br>';
            print '・ユーザー名:';
            print $add_user_name;
            print '<br>';
        }

        if($add_name=='')
        {
            print '・名前が入力されていません。<br>';
        }
        else
        {
            print '・名前:';
            print $add_name;
            print '<br>';
        }

        if($add_admission=='')
        {
            print '・入所月が選択されていません。<br>';
        }
        else
        {
        print '・入所月:';
        print $add_admission;
        print '<br>';
        }

        if($add_mail=='')
        {
            print '・メールアドレスが入力されていません。<br>';
        }
        else if(preg_match('/\A[\w\-\.]+\@[\w\-\.]+\.([a-z]+)\z/', $add_mail)==0)
        {
            print '・メールアドレスを正確に入力してください。';
        }
        else
        {
            print '・メールアドレス:';
            print $add_mail;
            print '<br>';
        }

        if($add_user_pass=='')
        {
            print '・パスワードが入力されていません。<br>';
        }

        if($add_user_pass!=$add_user_pass2)
        {
            print '・パスワードが一致しません。<br>';
        }

        if($add_user_name == '' || $add_name=='' || $add_user_pass == '' || $add_user_pass != $add_user_pass2 || $add_mail=='')
        {
            print '<br>';
            print '<div class="margin">';
            print '<button type="button" onclick="history.back()">戻る</button>';
            print '</div>';
        }
        else
        {
            $add_user_pass = md5($add_user_pass);
            print '<form method="post" action="signup_done.php">';
            print '<input type="hidden" name="user_name" value="'.$add_user_name.'">';
            print '<input type="hidden" name="pass" value="'.$add_user_pass.'">';
            print '<input type="hidden" name="name" value="'.$add_name.'">';
            print '<input type="hidden" name="admission" value="'.$add_admission.'">';
            print '<input type="hidden" name="mail" value="'.$add_mail.'">';
            print '<br>';
            print '　<button type="button" onclick="history.back()">戻る</button>　　　　　　　　　　';
            print '<button type="submit">ＯＫ</button>';

            // print '<input type="button" onclick="history.back()" value="戻る">';
            // print '<input type="submit" value="ＯＫ">';
            print '</form>';
        }

        ?>

                </label>
			</div>
		</div>
    </body>
</html>