<?php
    session_start();
    session_regenerate_id(true);

?> 



<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>利用者登録完了画面</title>
        <link rel="stylesheet" type="text/css" href="../common/common.css">
    	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
		.margin{
			margin-left: 140px;
		}
		.form {
			width: 390px;
			background: #fdfdfd;
			opacity: 0.95;
			/* padding-left: 30px; */
			padding-bottom: 10px;
			border-radius: 20px;
			box-shadow: 0 0 128px 0 rgba(0,0,0,0.2),0 32px 64px -48px rgba(0,0,0,0.7);
            text-align:center;
		}
        #central {
            margin: 0;
            position: absolute;
            top: 50%;
            left: 50%;
            margin-right: -50%;
            transform: translate(-50%, -50%)
        }
        #little_under {
            margin: 0;
            position: absolute;
            top: 70%;
            left: 50%;
            align-items: center;
            margin-right: -50%;
            transform: translate(-50%, -50%)
        }
        h2{
            color:black
        }
        </style>
    </head>
    <body class="all">
    <header>
            <p>利用者登録完了画面</p>
        </header>
        <br><br>
        <div class="form-container">
			<div class="form">
				<label>
    <?php
        try
        {
            require_once('../common/common.php');

            $post = sanitize($_POST);
            $add_user_name = $post['user_name'];
            $add_user_pass = $post['pass'];
            $add_name = $post['name'];
            $add_admission = $post['admission'];
            $add_mail = $post['mail'];

            $dsn = 'mysql:dbname=bus;host=localhost;charset=utf8';
            $user = 'root';
            $password = '';
            $dbh = new PDO($dsn, $user, $password);
            $dbh -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $sql = 'INSERT INTO user_info(user_name, user_pass, name, admission, mail) VALUES(?,?,?,?,?)';
            $stmt = $dbh -> prepare($sql);
            $data[] = $add_user_name;
            $data[] = $add_user_pass;
            $data[] = $add_name;
            $data[] = $add_admission;
            $data[] = $add_mail;
            $stmt -> execute($data);

            $dbh = null;

            // print '<div id=central>';
            print '<br>';
            print '<h2>✓登録完了</h2>';
            print $add_name;
            print 'さんを、ご入力頂いた情報で<br>';
            print 'メンバーに登録しました。';
            print '<br>';
            print '<br>';
            print 'トップページから<br>';
            print 'ログイン処理を行ってください。';
            print '<br>';
            // print '</div>';
            $top_m = isset($_SESSION['admin_login']) ? '../logout/admin_top.php':'../logout/login.html';

        }
        catch(Exception $e)
        {
            print 'ただいま障害により大変ご迷惑をおかけしております。';
            exit();
            print '<input type="button" onclick="history.back()" value="戻る">';
        }

    ?>
        <!-- <div id=little_under> -->
            <br>
            <button onclick="location.href='<?php echo $top_m;?>'" >トップページへ ▶</button>
        <!-- </div> -->
        </label>
			</div>
		</div>
    </body>
</html>